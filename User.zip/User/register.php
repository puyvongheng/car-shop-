<?php
include 'config/database.php';

$success_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $address = $_POST['address'];

    // Check if email already exists
    $checkEmailQuery = "SELECT id FROM user WHERE email = ?";
    $stmt = $conn->prepare($checkEmailQuery);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $success_message = "Email has already been used!";
    } else {
        // Hash the password
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        // Insert into database
        $sql = "INSERT INTO user (email, password_hash, first_name, last_name, address) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssss", $email, $password_hash, $first_name, $last_name, $address);

        if ($stmt->execute()) {
            $success_message = "Registration successful! Redirecting to login...";
            echo "<script>
                setTimeout(function(){
                    window.location.href = 'login.php?email=" . urlencode($email) . "&password=" . urlencode($password) . "';
                }, 3000); // Redirect after 3 seconds
                </script>";
        } else {
            echo "Error: " . $stmt->error;
        }
    }

    $stmt->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
      .bg-section {
  background: url('https://wallpapers.com/images/hd/4k-laptop-car-race-car-yzzkwdbdvwr3wn9s.jpg') no-repeat center center;
  background-size: cover;
  position: relative;
}

.bg-section::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 255, 0.5); /* Blue tint with 30% opacity */
  z-index: 1;
  pointer-events: none; /* This makes sure the overlay does not capture mouse events */
}

.bg-section > * {
  position: relative;
  z-index: 2; /* Ensure that content is above the overlay */
}
    </style>
</head>
<body>



<section class="bg-section">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col col-xl-10">
        <div class="card" style="border-radius: 1rem;">
          <div class="row g-0">
            <div class="col-md-6 col-lg-5 d-none d-md-block">

              <img src="https://i.pinimg.com/originals/01/a8/02/01a8028bc35cf9cb7db445c2ff3466bb.jpg"
                alt="login form" class="img-fluid" style="border-radius: 1rem 0 0 1rem;" />
            </div>

            <div class="col-md-6 col-lg-7 d-flex align-items-center">
              <div class="card-body p-4 p-lg-5 text-black">

                <form method="post">
             

                  <h5 id="a" class="fw-normal mb-3 pb-3" style="letter-spacing: 1px;">Register account</h5>

             <p id="successMessage"><?php echo htmlspecialchars($success_message); ?></p>

<script>
    setTimeout(function() {
        var successMessage = document.getElementById('successMessage');
        if (successMessage) {
            successMessage.style.display = 'none';
        }
    }, 5000); // 10000 milliseconds = 10 seconds
</script>



                  <div data-mdb-input-init class="form-outline mb-2">
                    <input type="email"  id="email" name="email" required class="form-control form-control-lg" />
                    <label class="form-label" for="email">Email address</label>
                  </div>

                  <div data-mdb-input-init class="form-outline mb-2">
                    <input type="password" id="password" name="password" required class="form-control form-control-lg" />
                    <label class="form-label"  for="password">Password</label>
                  </div>

         

                            <div class="row">

                <div class="col-md-6 mb-2">
                    <div data-mdb-input-init class="form-outline">
                    <input type="name" id="first_name" name="first_name" required class="form-control form-control-lg" />
                    <label class="form-label"  for="first_name">First Name:</label>
                  </div>
                  </div>
                  
                  <div class="col-md-6 mb-2">
                  <div data-mdb-input-init class="form-outline">
                    <input type="name" id="last_name" name="last_name" required class="form-control form-control-lg" />
                    <label class="form-label"  for="last_name">Last Name:</label>
                  </div>
                  </div>
                  </div>


                  
                  <div data-mdb-input-init class="form-outline mb-2">
                    <input type="address" id="address" name="address" required class="form-control form-control-lg" />
                    <label class="form-label"  for="password">Address</label>
                  </div>

                  <div class="pt-1 mb-2">
                    <button type="submit" data-mdb-button-init data-mdb-ripple-init class="btn btn-dark btn-lg btn-block" >Register</button>
                  </div>


           
                  <p class="" style="color: #393f81;">Don have an account? <a href="login.php"
                      style="color: #393f81;">login</a></p>
             
                </form>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>






<!--
<div class="container mt-5"></div>



    <h2>Register</h2>
    <form method="post">
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <div class="form-group">
            <label for="first_name">First Name:</label>
            <input type="text" class="form-control" id="first_name" name="first_name" required>
        </div>
        <div class="form-group">
            <label for="last_name">Last Name:</label>
            <input type="text" class="form-control" id="last_name" name="last_name" required>
        </div>
        <div class="form-group">
            <label for="address">Address:</label>
            <input type="text" class="form-control" id="address" name="address">
        </div>
        <button type="submit" class="btn btn-primary">Register</button>
    </form>
    <a class="nav-link" href="login.php">Login</a>
</div>
-->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
