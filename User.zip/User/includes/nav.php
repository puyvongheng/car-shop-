
<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>

<link rel="stylesheet" href="nav.css">
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
<style>
    <?php include ("nav.css"); ?>
</style>

<nav class="navbar navbar-expand-lg navbar-light bg-light">

    <img class="icon" src="Timmerman.png" alt="">

    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">

            <li class="nav-item">
                <a class="nav-link <?php echo in_array($current_page, ['index.php', 'details.php']) ? 'active' : ''; ?>" href="index.php"></i> <i class="fas fa-home"></i> Home</a>
            </li>




    


            <li class="nav-item dropdown <?php echo in_array($current_page, ['my_order_confirmation.php', 'view_cart.php']) ? 'active' : ''; ?>">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span><i class="fas fa-shopping-cart"></i></span>Cart
<?php
                $total_cart_quantity = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $total_cart_quantity += $item['quantity'];
    }
}
?>
                     <span class="badge badge-pill badge-primary"><?php echo $total_cart_quantity; ?></span>
            

            </a>
                <div class="dropdown-menu drop" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item <?php echo ($current_page == 'my_order_confirmation.php') ? 'active' : ''; ?>" href="my_order_confirmation.php">My Order</a>
                    <a class="dropdown-item <?php echo ($current_page == 'checkout.php') ? 'active' : ''; ?>" href="checkout.php">Checkout</a>
                    <a class="dropdown-item <?php echo ($current_page == 'view_cart.php') ? 'active' : ''; ?>" href="view_cart.php">MY Cart   <span class="badge badge-pill badge-primary"><?php echo $total_cart_quantity; ?></span> </a>
                </div>
            </li>


            <?php if (isset($_SESSION['user_id'])): ?><!--ប្រសិនបើមាន user id (មាន acont ) បង្អាញ list this-->
                <li class="nav-item"><a class="nav-link <?php echo ($current_page == 'profile.php') ? 'active' : ''; ?>" href="profile.php"><i class="fas fa-user"></i>acont</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
            <?php else: ?><!--ប្រសិនបើមិនមាន user id (មាន acont ) បង្អាញ list this-->
                <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                <li class="nav-item"><a class="nav-link" href="register.php">register</a></li>
            <?php endif; ?>


        </ul>
    </div>
</nav>