<?php
session_start(); // Start session to access user login status
include 'config/database.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}

// Check if model_id is provided
if (!isset($_GET['model_id']) || empty($_GET['model_id'])) {
    die("Model ID is missing.");
}

$model_id = intval($_GET['model_id']); // Sanitize input

// Fetch model details from the database
$sql = "SELECT * FROM model WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $model_id);
$stmt->execute();
$model_result = $stmt->get_result();

// Check if the model exists
if ($model_result->num_rows === 0) {
    die("Model not found.");
}

$model = $model_result->fetch_assoc();

// Initialize cart if not already done
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Add model to the cart
if (isset($_SESSION['cart'][$model_id])) {
    $_SESSION['cart'][$model_id]['quantity'] += 1; // Increment quantity if already in cart
} else {
    $_SESSION['cart'][$model_id] = array(

        'id' => $model['id'],
        'img' => $model['img'],
        'name' => $model['name'],
        'price' => $model['price'],
        'quantity' => 1
    );
}

// Redirect to cart page to view items
header("Location: view_cart.php");
exit();
?>
