<?php
// Start session
session_start();

// Include your database connection file
include('config/database.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login if not logged in
    header("Location: login.php");
    exit;
}

// Check if the review ID is provided
if (isset($_GET['id'])) {
    $review_id = intval($_GET['id']); // Sanitize the input

    // Fetch the review details to ensure it belongs to the logged-in user
    $query = "SELECT user_id FROM reviews WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $review_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $review = $result->fetch_assoc();

    // Check if the review exists and if the logged-in user owns the review
    if ($review && $review['user_id'] == $_SESSION['user_id']) {
        // Delete the review
        $delete_query = "DELETE FROM reviews WHERE id = ?";
        $delete_stmt = $conn->prepare($delete_query);
        $delete_stmt->bind_param("i", $review_id);
        if ($delete_stmt->execute()) {
            // Redirect to the details page with a success message
            $_SESSION['message'] = "Review deleted successfully.";
            
            echo "<script>
            if (window.history.length > 1) {
                window.history.go(-1);
            } else {
                window.history.back();
            }
          </script>";

            exit;
        } else {
            $_SESSION['error'] = "Error deleting the review.";
        }
    } else {
        $_SESSION['error'] = "You are not authorized to delete this review.";
    }
} else {
    $_SESSION['error'] = "No review ID provided.";
}

// Redirect back to details page
header("Location: details.php");
exit;
?>
