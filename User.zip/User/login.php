<?php
include 'config/database.php';

session_start();

$login_message = "";
$email = "";
$password = "";

// Check if email and password are passed via GET
if (isset($_GET['email']) && isset($_GET['password'])) {
    $email = $_GET['email'];
    $password = $_GET['password'];
    // Set a flag for auto-login
    $auto_login = true;
} else {
    $auto_login = false;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" || $auto_login) {
    if ($auto_login) {
        // Use GET parameters for email and password
        $email = $_GET['email'];
        $password = $_GET['password'];
    } else {
        // Use POST parameters for email and password
        $email = $_POST['email'];
        $password = $_POST['password'];
    }

    // Check credentials
    $sql = "SELECT id, password_hash FROM user WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($id, $password_hash);
    

    if ($stmt->num_rows > 0) {
        $stmt->fetch();
        if (password_verify($password, $password_hash)) {
            $_SESSION['user_id'] = $id;
            $_SESSION['email'] = $email;
            header("Location: index.php"); // Redirect to a protected page
            exit();
        } else {
            $login_message = "Incorrect password.";
        }
    } else {
        $login_message = "User not registered.";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
      .bg-section {
  background: url('https://wallpapers.com/images/hd/4k-laptop-car-race-car-yzzkwdbdvwr3wn9s.jpg') no-repeat center center;
  background-size: cover;
  position: relative;
}

.bg-section::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 255, 0.5); /* Blue tint with 30% opacity */
  z-index: 1;
  pointer-events: none; /* This makes sure the overlay does not capture mouse events */
}

.bg-section > * {
  position: relative;
  z-index: 2; /* Ensure that content is above the overlay */
}
    </style>
</head>
<body>


<section class="bg-section" style="background-color: #9A616D;">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col col-xl-10">
        <div class="card" style="border-radius: 1rem;">
          <div class="row g-0">
            <div class="col-md-6 col-lg-5 d-none d-md-block">
              <img src="https://i.pinimg.com/originals/01/a8/02/01a8028bc35cf9cb7db445c2ff3466bb.jpg"
                alt="login form" class="img-fluid" style="border-radius: 1rem 0 0 1rem;" />
            </div>
            <div class="col-md-6 col-lg-7 d-flex align-items-center">
              <div class="card-body p-4 p-lg-5 text-black">

                <form method="post">
                  <div class="d-flex align-items-center mb-3 pb-1">
                    <i class="fas fa-cubes fa-2x me-3" style="color: #ff6219;"></i>
                    <span class="h1 fw-bold mb-0">
                      <img style="width: 70px; height: 70px" src="Timmerman.png" alt="">
                    </span>
                  </div>

                  <h5 id="a" class="fw-normal mb-3 pb-3" style="letter-spacing: 1px;">Sign into your account

                  
                  <?php if (!empty($login_message)): ?>
                   <?php echo htmlspecialchars($login_message); ?> 
                 <?php endif; ?>
                  </h5>

                 
                 
                  <div data-mdb-input-init class="form-outline mb-4">
                    <input type="email"  id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required class="form-control form-control-lg" />
                    <label class="form-label" for="email">Email address</label>
                  </div>

                  <div data-mdb-input-init class="form-outline mb-4">
                    <input type="password" id="password" name="password"  value="<?php echo htmlspecialchars($password); ?>" required class="form-control form-control-lg" />
                    <label class="form-label"  for="password">Password</label>
                  </div>

                  <div class="pt-1 mb-4">
                    <button type="submit" data-mdb-button-init data-mdb-ripple-init class="btn btn-dark btn-lg btn-block" >Login</button>
                  </div>


                  <a class="small text-muted" href="#">Forgot password?</a>
                  <p class="mb-5 pb-lg-2" style="color: #393f81;">Don't have an account? <a href="register.php"
                      style="color: #393f81;">Register here</a></p>
           
                </form>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
