<?php
session_start();
include 'config/database.php';

// Set number of results per page
$results_per_page = 6;

// Base SQL query
$sql = "SELECT * FROM model WHERE 1=1";

// Apply filters
if (!empty($_GET['name'])) {
    $name = $conn->real_escape_string($_GET['name']);
    $sql .= " AND name LIKE '%$name%'";
}

if (!empty($_GET['carmaker'])) {
    $carmaker = (int)$_GET['carmaker'];
    $sql .= " AND id_car_makers = $carmaker";
}

if (!empty($_GET['year'])) {
    $year = (int)$_GET['year'];
    $sql .= " AND year = $year";
}

if (!empty($_GET['price'])) {
    $price = (float)$_GET['price'];
    $sql .= " AND price <= $price";
}

if (!empty($_GET['car_types'])) {
    $car_types = $conn->real_escape_string($_GET['car_types']);
    $sql .= " AND car_types = '$car_types'";
}

if (!empty($_GET['color'])) {
    $color = $conn->real_escape_string($_GET['color']);
    $sql .= " AND color = '$color'";
}

if (!empty($_GET['fuel_type'])) {
    $fuel_type = $conn->real_escape_string($_GET['fuel_type']);
    $sql .= " AND fuel_type = '$fuel_type'";
}

// Count total results
$count_sql = str_replace("SELECT *", "SELECT COUNT(id) AS total", $sql);
$count_result = $conn->query($count_sql);
$count_row = $count_result->fetch_assoc();
$total_results = $count_row['total'];

// Calculate total pages
$total_pages = ceil($total_results / $results_per_page);

// Determine current page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max(1, min($page, $total_pages)); // Ensure page number is within range

// Calculate starting limit
$start_from = ($page - 1) * $results_per_page;

// Add LIMIT clause
$sql .= " LIMIT $start_from, $results_per_page";

$result = $conn->query($sql);

// Fetch user info if logged in
$user_email = isset($_SESSION['user_email']) ? htmlspecialchars($_SESSION['user_email']) : '';
$user_last_name = isset($_SESSION['user_last_name']) ? htmlspecialchars($_SESSION['user_last_name']) : '';
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Models</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        .car-box {
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 5px;
            text-align: start;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            justify-content: center;
        }
     
        .car-box:hover {
            transform: translateY(-10px);
            box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.1);
            
        }
        .car-box img {
            max-width: 100%;
            height: auto;
            border-radius: 5px;
        }
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }
        .pagination li {
            margin: 0 5px;
        }
   



    .car-link {
        text-decoration: none;
      
    }
    .car-link:hover  {
        text-decoration: none;
      
    }


    
   
    </style>
</head>
<body>

<!-- Navigation Bar -->
<?php include 'includes/nav.php'; ?>




<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#"></a>
    <div class="collapse navbar-collapse" id="navbarNav">
        <form method="GET" action="index.php" class="form-inline">

            <div class="form-group mr-2">
                <input type="text" name="name" class="form-control" placeholder="Car Name" value="<?php echo isset($_GET['name']) ? htmlspecialchars($_GET['name']) : ''; ?>">
            </div>

            
            <div class="form-group mr-2">
                <select name="carmaker" class="form-control">
                    <option value="">maker</option>
                    <?php
                    $carmaker_sql = "SELECT DISTINCT id, maker_name FROM car_makers";
                    $carmaker_result = $conn->query($carmaker_sql);
                    while ($carmaker_row = $carmaker_result->fetch_assoc()): ?>
                        <option value="<?php echo $carmaker_row['id']; ?>" <?php echo isset($_GET['carmaker']) && $_GET['carmaker'] == $carmaker_row['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($carmaker_row['maker_name']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <div class="form-group mr-2">
                <select name="year" class="form-control">
                    <option value="">Year</option>
                    <?php
                    $year_sql = "SELECT DISTINCT year FROM model ORDER BY year DESC";
                    $year_result = $conn->query($year_sql);
                    while ($year_row = $year_result->fetch_assoc()): ?>
                        <option value="<?php echo $year_row['year']; ?>" <?php echo isset($_GET['year']) && $_GET['year'] == $year_row['year'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($year_row['year']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <div class="form-group mr-2">
                <select name="car_types" class="form-control">
                    <option value="">Car Type</option>
                    <?php
                    $car_types_sql = "SELECT DISTINCT car_types FROM model ORDER BY car_types";
                    $car_types_result = $conn->query($car_types_sql);
                    while ($car_types_row = $car_types_result->fetch_assoc()): ?>
                        <option value="<?php echo $car_types_row['car_types']; ?>" <?php echo isset($_GET['car_types']) && $_GET['car_types'] == $car_types_row['car_types'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($car_types_row['car_types']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <div class="form-group mr-2">
                <select name="color" class="form-control">

                    <option value="">Color</option>
                    <?php

                    $colors = ['Beige', 'Black', 'Blue', 'Brown', 'Gold', 'Gray', 'Green', 'Orange', 'Purple', 'Red', 'Silver', 'White', 'Yellow'];
                    foreach ($colors as $color): ?>
                        <option value="<?php echo $color; ?>" <?php echo isset($_GET['color']) && $_GET['color'] == $color ? 'selected' : ''; ?>>
                            <?php echo $color; ?>
                        </option>
                    <?php endforeach; ?>
                    
                </select>
            </div>
            
            <div class="form-group mr-2">
                <select name="fuel_type" class="form-control">
                    <option value="">Fuel Type</option>
                    <?php
                    $fuel_type_sql = "SELECT DISTINCT fuel_type FROM model ORDER BY fuel_type";
                    $fuel_type_result = $conn->query($fuel_type_sql);
                    while ($fuel_type_row = $fuel_type_result->fetch_assoc()): ?>
                        <option value="<?php echo $fuel_type_row['fuel_type']; ?>" <?php echo isset($_GET['fuel_type']) && $_GET['fuel_type'] == $fuel_type_row['fuel_type'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($fuel_type_row['fuel_type']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <div class="form-group mr-2">
                <input type="number" name="price" class="form-control" placeholder="Max Price$" value="<?php echo isset($_GET['price']) ? htmlspecialchars($_GET['price']) : ''; ?>">
            </div>
            
            <button type="submit" class="btn btn-primary">Search <i class="fas fa-search"></i></button>
        </form>
    </div>
</nav>




<div class="container mt-5">


<div class=" mt-5 car-box ">
   
    <div class="row">
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="col-md-4 " style="text-align: start;">
                    <a href="details.php?model_id=<?php echo $row['id']; ?>" class="car-link">
                        <div class="car-box">
            <!-- img -->
                        <?php if ($row['img']): ?>
                            <?php if (filter_var($row['img'], FILTER_VALIDATE_URL)): ?>
                                <img src="<?php echo htmlspecialchars($row['img']); ?>" alt="Image">
                            <?php else: ?>
                                <img src="../../Admin/src/uploads/imagesmodel/<?php echo htmlspecialchars($row['img']); ?>" alt="Image">
                            <?php endif; ?>
                        <?php else: ?>
                            <p>No Image Available</p>
                        <?php endif; ?>
            <!--end img -->

                        <div class="card-body ">
                            <p class=" text-dark"><?php echo htmlspecialchars($row['name']); ?></p>
                            <h4 style="color: red;" class=" custom-color"><strong> $<?php echo number_format($row['price'], 2); ?></strong></h4>
                      <P>            <img height="10px" width="70px" src="https://static.vecteezy.com/system/resources/thumbnails/021/630/211/small_2x/stars-customer-reviews-illustration-png.png" alt="">
                      </P>
                        </div>
                            
                        </div>
                    </a>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No car models found.</p>
        <?php endif; ?>
    </div>
</div>




<?php
// Get current query parameters, excluding the page parameter
$params = $_GET;
unset($params['page']);

// Build the base URL with existing parameters
$base_url = 'index.php?' . http_build_query($params) . '&page=';
?>

<ul class="pagination">
    <?php if ($page > 1): ?>
        <li><a href="<?php echo $base_url; ?>1" class="btn btn-light">1</a></li>
        <li><a href="<?php echo $base_url; ?><?php echo $page - 1; ?>" class="btn btn-light">Previous</a></li>
    <?php endif; ?>

    <?php
    $start = max(1, $page - 2);
    $end = min($total_pages, $page + 2);

    if ($start > 1) echo '<li>...</li>';
    
    for ($i = $start; $i <= $end; $i++): ?>
        <li><a href="<?php echo $base_url; ?><?php echo $i; ?>" class="btn btn-light <?php if ($page == $i) echo 'active'; ?>"><?php echo $i; ?></a></li>
    <?php endfor; ?>

    <?php if ($end < $total_pages): ?>
        <li>...</li>
        <li><a href="<?php echo $base_url; ?><?php echo $total_pages; ?>" class="btn btn-light"><?php echo $total_pages; ?></a></li>
        <li><a href="<?php echo $base_url; ?><?php echo $page + 1; ?>" class="btn btn-light">Next</a></li>
    <?php endif; ?>
</ul>



</div>




</div>

<footer>

</footer>

<!-- Navigation Bar -->
<?php include 'includes/footer.php'; ?>




<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
$conn->close();
?>
