<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Cars.com</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
    font-family: Arial, sans-serif;
}

header h1 {
    font-size: 2.5rem;
}

footer p {
    margin: 0;
}

.card-img-top {
    max-height: 200px;
    object-fit: cover;
}

a {
    color: #007bff;
}

a:hover {
    text-decoration: underline;
}

    </style>
</head>
<body>

<!-- Navigation Bar -->
<?php include 'includes/nav.php'; ?>




    <header class="bg-primary text-white text-center py-4">
        <h1>About Cars.com</h1>
    </header>

    <main class="container my-5">
        <section id="who-we-are" class="mb-5">
            <h2 class="mb-3">Who We Are</h2>
            <p>
                Cars.com is the No. 1 most recognized automotive marketplace visited by more than 25 million in-market consumers each month. Launched in 1998 and headquartered in Chicago, Cars.com empowers shoppers with the data, resources, and digital tools needed to make informed buying decisions and seamlessly connect with automotive retailers.
            </p>
            <p>
                Cars.com is the flagship offering from Cars.com Inc. d/b/a Cars Commerce, an audience-driven technology company empowering automotive that simplifies everything about buying and selling cars. Learn more at <a href="http://www.carscommerce.inc">www.carscommerce.inc</a>.
            </p>
        </section>

        <section id="our-roots" class="mb-5">
            <h2 class="mb-3">Our Roots</h2>
            <p>
                Cars.com invented car search. Our site and innovative solutions connect buyers and sellers to match people with their perfect car. With our people spread across the U.S., we still maintain a startup culture with innovation and passion for our people at the core of everything we do.
            </p>
            <p>
                Cars.com has an award-winning brand, leadership team, and the best and brightest employees in the industry. We’ve been featured as one of the top places to work by The Chicago Tribune, Built in Chicago, Chicago Innovation, and U.S. News & World Report.
            </p>
        </section>

        <section id="leadership" class="mb-5">
            <h2 class="mb-3">Leadership Team</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="card mb-4">
                        <img src="path/to/alex-vetter.jpg" class="card-img-top" alt="Alex Vetter">
                        <div class="card-body">
                            <h5 class="card-title">Alex Vetter</h5>
                            <p class="card-text">Chief Executive Officer</p>
                        </div>
                    </div>
                </div>
                <!-- Repeat similar blocks for other leaders -->
            </div>
        </section>

        <section id="pressroom" class="mb-5">
            <h2 class="mb-3">From the Pressroom</h2>
            <ul class="list-unstyled">
                <li><a href="#" class="d-block">Aug 16, 2024: New-Car Market Sees Sharp Decline in Sub-$30,000 Vehicles</a></li>
                <li><a href="#" class="d-block">Aug 13, 2024: Family First: Cars.com Survey Finds Over 60% of Parents Purchase a Vehicle Based on Car Seat Needs</a></li>
                <li><a href="#" class="d-block">Aug 8, 2024: Cars.com Reports Second Quarter 2024 Results</a></li>
            </ul>
        </section>

        <section id="contact-us" class="mb-5">
            <h2 class="mb-3">Our Office</h2>
            <address>
                <p>Cars.com</p>
                <p>300 South Riverside, Suite 1000</p>
                <p>Chicago, IL 60606</p>
                <p><a href="http://www.carscommerce.inc">www.carscommerce.inc</a></p>
            </address>
        </section>
    </main>



    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
