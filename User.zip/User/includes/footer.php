<!-- footer.php -->
<?php
// Include database configuration


// Query to get car makers
$carmaker_query = "SELECT id, maker_name FROM car_makers";
$carmaker_result = $conn->query($carmaker_query);

// Query to get distinct car types
$car_types_sql = "SELECT DISTINCT car_types FROM model ORDER BY car_types";
$car_types_result = $conn->query($car_types_sql);
?>

<footer class="bg-dark text-light py-4">
    <div class="container">
        <div class="row">
            <!-- Buying & Selling Column -->
            <div class="col-md-2 mb-3">
                <h5>Buying & Selling</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-light">Financing</a></li>
                    <li><a href="#" class="text-light">Find a Car</a></li>
                    <li><a href="#" class="text-light">Find a Dealer</a></li>
                    <li><a href="#" class="text-light">Listings by City</a></li>
                    <li><a href="#" class="text-light">Certified Pre-Owned</a></li>
                    <li><a href="#" class="text-light">Car Payment Calculators</a></li>
                    <li><a href="#" class="text-light">Car Reviews & Ratings</a></li>
                    <li><a href="#" class="text-light">Compare Side by Side</a></li>
                    <li><a href="#" class="text-light">Fraud Awareness</a></li>
                    <li><a href="#" class="text-light">Sell Your Car</a></li>
                </ul>
            </div>

            <!-- Explore Our Brand Column -->
            <div class="col-md-2 mb-3">
                <h5>Explore Our Brand</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-light">NewCars.com</a></li>
                    <li><a href="#" class="text-light">DealerRater</a></li>
                    <li><a href="#" class="text-light">For Dealer Partners</a></li>
                    <li><a href="#" class="text-light">Platform Log-In</a></li>
                    <li><a href="#" class="text-light">Cars Commerce Overview</a></li>
                    <li><a href="#" class="text-light">Cars.com</a></li>
                    <li><a href="#" class="text-light">Dealer Inspire</a></li>
                    <li><a href="#" class="text-light">AccuTrade</a></li>
                    <li><a href="#" class="text-light">Cars Commerce Media Network</a></li>
                </ul>
            </div>

            <!-- Our Company Column -->
            <div class="col-md-2 mb-3">
                <h5>Our Company</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-light">About Cars.com</a></li>
                    <li><a href="#" class="text-light">Contact Cars.com</a></li>
                    <li><a href="#" class="text-light">Investor Relations</a></li>
                    <li><a href="#" class="text-light">Careers</a></li>
                    <li><a href="#" class="text-light">Licensing & Reprints</a></li>
                    <li><a href="#" class="text-light">Site Map</a></li>
                    <li><a href="#" class="text-light">Feedback</a></li>
                </ul>
            </div>

            <!-- Payment Methods Column -->
            <div class="col-md-2 mb-3">
                <h5>Payment Methods</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-light">Credit Card</a></li>
                    <li><a href="#" class="text-light">Debit Card</a></li>
                    <li><a href="#" class="text-light">PayPal</a></li>
                    <li><a href="#" class="text-light">Apple Pay</a></li>
                    <li><a href="#" class="text-light">Google Pay</a></li>
                    <li><a href="#" class="text-light">Bank Transfer</a></li>
                </ul>
            </div>

   

            <!-- Mobile App & Social Media -->
            <div class="col-md-2 mb-3">
                <h5>Our Mobile App</h5>
                <a href="#"><img src="path_to_app_store_badge.png" alt="Download on the App Store" class="img-fluid mb-2"></a>
                <a href="#"><img src="path_to_google_play_badge.png" alt="Get it on Google Play" class="img-fluid"></a>

                <h5 class="mt-3">Connect With Us</h5>
                <div class="social-icons mt-2">
                    <a href="#" class="text-light me-2"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="text-light me-2"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="text-light me-2"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="text-light me-2"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#" class="text-light"><i class="fab fa-youtube"></i></a>
                </div>
                
                <ul class="list-unstyled mt-3">
                    <li><a href="#" class="text-light">Terms & Conditions of Use</a></li>
                    <li><a href="#" class="text-light">Privacy Notice</a></li>
                    <li><a href="#" class="text-light">California Privacy Notice</a></li>
                    <li><a href="#" class="text-light">My Privacy Choices</a></li>
                    <li><a href="#" class="text-light">Cookie Preferences</a></li>
                    <li><a href="#" class="text-light">Accessibility Statement</a></li>
                    <li><a href="#" class="text-light">Ad Choices</a></li>
                    <li><a href="#" class="text-light">Do Not Sell My Information</a></li>
                </ul>
            </div>

                 
            <!-- Car Types Column -->
            <div class="col-md-2 mb-3">
                <h5>Car Types</h5>
                <a class="dropdown-item" href="#">Car Type</a>
                <?php while ($car_types_row = $car_types_result->fetch_assoc()): ?>
                    <?php
                    $car_type = htmlspecialchars($car_types_row['car_types']);
                    ?>
                    <a class="dropdown-item text-light" href="index.php?car_types=<?php echo urlencode($car_type); ?>">
                        <?php echo $car_type; ?>
                    </a>
                <?php endwhile; ?>
            </div>


                <!-- Car Makers Column -->
                <div class="col-md-2 mb-3">
                <h5>Car Makers</h5>
                <?php while ($carmaker_row = $carmaker_result->fetch_assoc()): ?>
                    <a class="dropdown-item text-light" href="index.php?carmaker=<?php echo $carmaker_row['id']; ?>">
                        <?php echo htmlspecialchars($carmaker_row['maker_name']); ?>
                    </a>
                <?php endwhile; ?>
            </div>




        </div>
    </div>
    <div class="text-center py-3">
        <p class="mb-0">&copy; <?php echo date('Y'); ?> Your Company Name. All rights reserved.</p>
    </div>
</footer>

<!-- Include necessary JavaScript libraries -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.11.6/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.min.js"></script>

<!-- Add custom JavaScript if needed -->
<script>
    // Your custom JavaScript code
</script>
</body>
</html>
