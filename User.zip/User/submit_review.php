<?php
// Include the database connection
include 'config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve the form data
    $user_id = $_POST['user_id']; // Assuming user_id is stored in session or passed via hidden input
    $model_id = $_POST['model_id']; // Assuming model_id is passed via hidden input
    $rating = intval($_POST['rating']);
    $review_text = trim($_POST['review']);

    // Validation
    if ($rating < 1 || $rating > 5) {
        die("Invalid rating. Please submit a rating between 1 and 5.");
    }
    if (empty($review_text)) {
        die("Please write a review before submitting.");
    }

    // Prepare the SQL query to insert the review
    $sql = "INSERT INTO reviews (user_id, model_id, rating, review_text) VALUES (?, ?, ?, ?)";

    // Using prepared statements to prevent SQL injection
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param('iiis', $user_id, $model_id, $rating, $review_text);

        // Execute the query
        if ($stmt->execute()) {
            // Success message
          //   echo "Review submitted successfully!";
          //   header("Location: model_details.php?id=" . $model_id); // Redirect to model details page
            echo "<script>
            if (window.history.length > 1) {
                window.history.go(-1);
            } else {
                window.history.back();
            }
          </script>";

        } else {
            echo "Error: Could not submit the review.";
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "Error: Could not prepare the SQL statement.";
    }

    // Close the database connection
    $conn->close();
}
?>
