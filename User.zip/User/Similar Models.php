



<?php

session_start();

include 'config/database.php';
include 'includes/nav.php'; 
$model_id = $_GET['model_id'];
// ទាញយកព័ត៌មានពីម៉ូដែលជាក់លាក់
$sql = "SELECT * FROM model WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $model_id);
$stmt->execute();
$model = $stmt->get_result()->fetch_assoc();
// បញ្ចូលព័ត៌មានអំពីប្រភេទឡានដែលស្រដៀងគ្នា
$sql_similar = "SELECT id, name, img, price FROM model WHERE car_types = ? AND id != ?";
$stmt_similar = $conn->prepare($sql_similar);
$stmt_similar->bind_param("si", $model['car_types'], $model_id);
$stmt_similar->execute();
$similar_models = $stmt_similar->get_result();

?>
<div class="container mt-5">

    
  
            <h3>Similar Models</h3>

            <?php if ($similar_models->num_rows > 0): ?>
                <?php while ($row = $similar_models->fetch_assoc()): ?>

                    <a href="details.php?model_id=<?php echo $row['id']; ?>" >
                    <div class="similar-car-box mb-4 p-3 border rounded" style="text-align: start;">
                        <!-- img -->
                         
                        <?php if ($row['img']): ?>
                            <img src="<?php echo htmlspecialchars($row['img']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>" class="img-fluid mb-3">
                        <?php else: ?>
                            <p>No Image Available</p>
                        <?php endif; ?>
                        <!-- end img -->

                        <h6><?php echo htmlspecialchars($row['name']); ?></h6>
                        <h4 style="color: red;"><strong>$<?php echo number_format($row['price'], 2); ?></strong></h4>
                
                    </div>
                    </a>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No similar models found.</p>
            <?php endif; ?>

        </div>

    </div>
</div>
<?php $conn->close(); ?>