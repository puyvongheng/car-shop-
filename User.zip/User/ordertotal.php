<?php
session_start(); // Start session to access admin login status
include 'config/database.php'; // Include database configuration


// Fetch all orders
$orders_query = "SELECT o.id, o.order_date, o.total_price, u.first_name, u.last_name
                 FROM orders o
                 JOIN user u ON o.user_id = u.id
                 ORDER BY o.order_date DESC";
$result = $conn->query($orders_query);

// Check for new orders today
$today = date('Y-m-d');
$new_orders_query = "SELECT COUNT(*) AS new_count FROM orders WHERE DATE(order_date) = ?";
$stmt = $conn->prepare($new_orders_query);
$stmt->bind_param("s", $today);
$stmt->execute();
$new_orders_result = $stmt->get_result();
$new_orders_count = $new_orders_result->fetch_assoc()['new_count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Orders</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .order-summary {
            margin-bottom: 30px;
        }
        .notification {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid #d4edda;
            border-radius: 5px;
            background-color: #d4edda;
            color: #155724;
        }
    </style>
</head>
<body>
<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">Admin Dashboard</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="admin_dashboard.php">Dashboard</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="ordertotal.php">View Orders</a>
            </li>
            <!-- Add other admin links here -->
            <li class="nav-item">
                <a class="nav-link" href="logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>

<div class="container mt-5">
    <h2>All Orders</h2>

    <?php if ($new_orders_count > 0): ?>
        <div class="notification">
            <strong>New Orders Alert!</strong> There are <?php echo $new_orders_count; ?> new order(s) today.
        </div>
    <?php endif; ?>
    
    <?php if ($result->num_rows > 0): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>User Name</th>
                    <th>Order Date</th>
                    <th>Total Price</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($order = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($order['id']); ?></td>
                        <td><?php echo htmlspecialchars($order['first_name'] . ' ' . $order['last_name']); ?></td>
                        <td><?php echo htmlspecialchars($order['order_date']); ?></td>
                        <td>$<?php echo number_format($order['total_price'], 2); ?></td>
                        <td><a href="order_itemstotal.php?order_id=<?php echo htmlspecialchars($order['id']); ?>" class="btn btn-info btn-sm">View Items</a></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No orders found.</p>
    <?php endif; ?>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
