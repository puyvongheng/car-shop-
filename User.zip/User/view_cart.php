<?php
session_start(); // 
include 'config/database.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}


// Handle checkout (optional)
if (isset($_POST['checkout'])) {
    // Add checkout logic here (e.g., saving order to database, redirecting to payment gateway)
    header("Location: checkout.php");
    exit();
}


// Handle item removal from cart
if (isset($_POST['remove_item']) && isset($_POST['model_id'])) {
    $model_id = intval($_POST['model_id']); // Sanitize input
    if (isset($_SESSION['cart'][$model_id])) {
        unset($_SESSION['cart'][$model_id]); // Remove item from cart
    }
    header("Location: view_cart.php"); // Redirect to refresh cart
    exit();
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
    
    </style>
</head>

<body>

    <!-- Navigation Bar -->
    <?php include 'includes/nav.php'; ?>





    <div class="container mt-5">


    <?php
$total_cart_quantity = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $total_cart_quantity += $item['quantity'];
    }
}
?>
 <span class="badge badge-pill badge-primary"><?php echo $total_cart_quantity; ?></span>
    <h2>Your Cart  </h2>
    <?php if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])): ?>
        <form method="POST" action="view_cart.php">
            <div class="row">
                <div class="col-12">
                    <?php
                    $total_price = 0;
                    foreach ($_SESSION['cart'] as $item):
                        $item_total = $item['price'] * $item['quantity'];
                        $total_price += $item_total;
                    ?>

                        <div class="row align-items-center border-bottom py-3">
                            <!-- Image 📷 -->
                            <div class="col-2">
                                <?php if (!empty($item['img'])): ?>
                                    <?php if (filter_var($item['img'], FILTER_VALIDATE_URL)): ?>
                                        <img src="<?php echo htmlspecialchars($item['img']); ?>" alt="<?php echo htmlspecialchars($item['img']); ?>" class="img-fluid" style="max-width: 100px;">
                                    <?php else: ?>
                                        <img src="../uploads/imagesmodel/<?php echo htmlspecialchars($item['img']); ?>" alt="<?php echo htmlspecialchars($item['img']); ?>" class="img-fluid" style="max-width: 100px;">
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span>No Image</span>
                                <?php endif; ?>
                            </div>
                            <!-- Image 📷 -->


                            
                            <!-- Name -->
                            <div class="col-2">
                            <a href="details.php?model_id=<?php echo htmlspecialchars($item['id']); ?>" class="car-link">
                                <p class="mb-0"><?php echo htmlspecialchars($item['name']); ?></p>
                            </a>

                            </div>
                            <!-- Price -->
                            <div class="col-2">
                                <p class="mb-0">$<?php echo number_format($item['price'], 2); ?></p>
                            </div>
                            <!-- Quantity -->
                            <div class="col-2">
                                <p class="mb-0"><?php echo htmlspecialchars($item['quantity']); ?></p>
                            </div>
                            <!-- Total -->
                            <div class="col-2">
                                <p class="mb-0">$<?php echo number_format($item_total, 2); ?></p>
                            </div>
                            <!-- Action -->
                            <div class="col-2 text-right">
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="model_id" value="<?php echo htmlspecialchars($item['id']); ?>">
                                    <button type="submit" name="remove_item" class="btn btn-danger btn-sm" style="border-radius: 20px;">Remove</button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    <!-- Total Price -->
                    <div class="row mt-4">
                        <div class="col text-right">
                            <h4>Total: $<?php echo number_format($total_price, 2); ?></h4>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Checkout Button -->
            <div class="row mt-3">
                <div class="col text-right">
                    <!--    <button type="submit" name="checkout" class="btn btn-success">Proceed to Checkout</button>-->
<a  class="btn btn-success" style="border-radius: 20px;" href="checkout.php">checkout</a>
                </div>
            </div>
        </form>
    <?php else: ?>
        <p>Your cart is empty.</p>
    <?php endif; ?>
</div>


<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
