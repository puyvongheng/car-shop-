<?php

header('Location: src/pages/login.php');

?>