



<?php

session_start();
include 'config/database.php';




include 'includes/nav.php'; ?>

<?php

// SQL query to get total sales for each model
$sql = "SELECT m.id, m.name, m.full_name, m.img, m.price, SUM(oi.quantity) AS total_quantity
        FROM model m
        JOIN order_items oi ON m.id = oi.model_id
        JOIN orders o ON oi.order_id = o.id
        GROUP BY m.id
        ORDER BY total_quantity DESC
        ";

$result = $conn->query($sql);

// Create an array to store total quantities
$quantities = [];
while ($row = $result->fetch_assoc()) {
    $quantities[] = $row['total_quantity'];
}
// Remove duplicate quantities and sort them in descending order
$quantities = array_unique($quantities);
rsort($quantities);

// Define rank thresholds based on sorted quantities
$rank_thresholds = [];
foreach ($quantities as $index => $quantity) {
    if ($index == 0) {
        $rank_thresholds['Top 1'] = $quantity;
    } elseif ($index == 1) {
        $rank_thresholds['Top 2'] = $quantity;
    } elseif ($index == 2) {
        $rank_thresholds['Top 3'] = $quantity;
    } else {
        break;
    }
}
// Re-run the query to fetch results for displaying
$result->data_seek(0);
?>

<div class="container mt-5">
<div class="row">
    <?php if ($result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
            <?php
            // Determine the ranking based on the total quantity
            $ranking = "";
            if ($row['total_quantity'] >= $rank_thresholds['Top 1']) {
                $ranking = "Top 1";
            } elseif ($row['total_quantity'] >= $rank_thresholds['Top 2']) {
                $ranking = "Top 2";
            } elseif ($row['total_quantity'] >= $rank_thresholds['Top 3']) {
                $ranking = "Top 3";
            }
            ?>
            <div class="col-md-4 mb-4">
                <a href="details.php?model_id=<?php echo $row['id']; ?>" class="car-link">
                    <div class="car-box p-3 border rounded" style="text-align: start;">
                        <!--img -->
                        <?php if ($row['img']): ?>
                            <img src="<?php echo htmlspecialchars($row['img']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>" class="img-fluid mb-3">
                        <?php else: ?>
                            <p>No Image Available</p>
                        <?php endif; ?>
                        <!--end img-->

                        <h6><?php echo htmlspecialchars($row['name']); ?></h6>
                        <h4 style="color: red;"><strong>$<?php echo number_format($row['price'], 2); ?></strong></h4>
                        <p><?php echo $row['total_quantity']; ?> Sold ( <?php echo $ranking; ?>)
                        <img height="10px" width="70px" src="https://static.vecteezy.com/system/resources/thumbnails/021/630/211/small_2x/stars-customer-reviews-illustration-png.png" alt="">

                    </p>
                     
                    </div>
                </a>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No car models available.</p>
    <?php endif; ?>

    <?php $conn->close(); ?>
</div>
</div>
</div>
<!-- container box product 🚙🚙 🔝-->