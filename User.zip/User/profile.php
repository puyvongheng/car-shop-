<?php
session_start(); // Start session to access user login status
include 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}

// Fetch user information from the database
$user_id = $_SESSION['user_id'];
$sql = "SELECT email, first_name, last_name, address FROM user WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $user_email = htmlspecialchars($user['email']);
    $user_first_name = htmlspecialchars($user['first_name']);
    $user_last_name = htmlspecialchars($user['last_name']);
    $user_address = htmlspecialchars($user['address']);
} else {
    echo "User not found.";
    exit();
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $new_first_name = $_POST['first_name'];
    $new_last_name = $_POST['last_name'];
    $new_address = $_POST['address'];

    // Validate input
    if (empty($new_first_name) || empty($new_last_name) || empty($new_address)) {
        $error_message = "All fields are required.";
    } else {
        // Update user information in the database
        $update_sql = "UPDATE user SET first_name = ?, last_name = ?, address = ? WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("sssi", $new_first_name, $new_last_name, $new_address, $user_id);
        if ($update_stmt->execute()) {
            $success_message = "Profile updated successfully.";
            $_SESSION['user_first_name'] = $new_first_name; // Update session
            $_SESSION['user_last_name'] = $new_last_name; // Update session
            $_SESSION['user_address'] = $new_address; // Update session
            // Refresh the page to show updated info
            header("Location: profile.php");
            exit();
        } else {
            $error_message = "Failed to update profile.";
        }
    }
}

// Handle password update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_password'])) {
    $current_password = $_POST['current_password'];
    $new_password1 = $_POST['new_password1'];
    $new_password2 = $_POST['new_password2'];

    // Validate input
    if (empty($current_password) || empty($new_password1) || empty($new_password2)) {
        $password_error_message = "All fields are required.";
    } elseif ($new_password1 !== $new_password2) {
        $password_error_message = "New passwords do not match.";
    } else {
        // Fetch current password hash from the database
        $sql = "SELECT password_hash FROM user WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        // Verify current password
        if (password_verify($current_password, $user['password_hash'])) {
            // Hash new password and update database
            $new_password_hash = password_hash($new_password1, PASSWORD_BCRYPT);
            $update_password_sql = "UPDATE user SET password_hash = ? WHERE id = ?";
            $update_password_stmt = $conn->prepare($update_password_sql);
            $update_password_stmt->bind_param("si", $new_password_hash, $user_id);
            if ($update_password_stmt->execute()) {
                $password_success_message = "Password updated successfully.";
            } else {
                $password_error_message = "Failed to update password.";
            }
        } else {
            $password_error_message = "Current password is incorrect.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

    <!-- Navigation Bar -->
    <?php include 'includes/nav.php'; ?>


<div class="container mt-5">
    <h2>Profile</h2>
    
    <?php if (isset($success_message)): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
    <?php endif; ?>
    
    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <?php if (isset($password_success_message)): ?>
        <div class="alert alert-success"><?php echo $password_success_message; ?></div>
    <?php endif; ?>

    <?php if (isset($password_error_message)): ?>
        <div class="alert alert-danger"><?php echo $password_error_message; ?></div>
    <?php endif; ?>
    
    <form action="profile.php" method="POST">
        <h3>Update Profile</h3>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" value="<?php echo $user_email; ?>" readonly>
        </div>


        
        <div class="row">


        <div class="col-md-6 mb-2">
        <div class="form-group">
            <label for="first_name">First Name:</label>
            <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo $user_first_name; ?>">
        </div>
        </div>
        <div class="col-md-6 mb-2">
        <div class="form-group">
            <label for="last_name">Last Name:</label>
            <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo $user_last_name; ?>">
        </div>
        </div>

        </div>



        <div class="form-group">
            <label for="address">Address:</label>
            <input type="text" class="form-control" id="address" name="address" value="<?php echo $user_address; ?>">
        </div>
        <button type="submit" name="update_profile" class="btn btn-primary">Update Profile</button>
    </form>

    <form action="profile.php" method="POST" class="mt-4">
        <h3>Change Password</h3>
        <div class="form-group">
            <label for="current_password">Current Password:</label>
            <input type="password" class="form-control" id="current_password" name="current_password">
        </div>
        <div class="form-group">
            <label for="new_password1">New Password:</label>
            <input type="password" class="form-control" id="new_password1" name="new_password1">
        </div>
        <div class="form-group">
            <label for="new_password2">Confirm New Password:</label>
            <input type="password" class="form-control" id="new_password2" name="new_password2">
        </div>
        <button type="submit" name="update_password" class="btn btn-primary">Update Password</button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
$conn->close();
?>
