<?php
session_start();
header('Content-Type: application/json');
include 'config/database.php';

$response = array('status' => 'error', 'message' => 'Invalid request');

if (isset($_SESSION['user_id']) && isset($_POST['model_id'])) {
    $userId = $_SESSION['user_id'];
    $modelId = intval($_POST['model_id']);
    
    if (isset($_POST['remove']) && $_POST['remove'] == 'true') {
        // Remove from favorites
        $stmt = $pdo->prepare("DELETE FROM favorites WHERE user_id = ? AND model_id = ?");
        if ($stmt->execute([$userId, $modelId])) {
            $response['status'] = 'success';
            $response['message'] = 'Removed from favorites';
        } else {
            $response['message'] = 'Failed to remove from favorites';
        }
    } else {
        // Add to favorites
        $stmt = $pdo->prepare("INSERT INTO favorites (user_id, model_id) VALUES (?, ?) ON DUPLICATE KEY UPDATE model_id = model_id");
        if ($stmt->execute([$userId, $modelId])) {
            $response['status'] = 'success';
            $response['message'] = 'Added to favorites';
        } else {
            $response['message'] = 'Failed to add to favorites';
        }
    }
} else {
    $response['message'] = 'User not logged in or model ID missing';
}

echo json_encode($response);
