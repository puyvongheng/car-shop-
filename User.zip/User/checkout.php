<?php
session_start(); // Start session to access user login status
include 'config/database.php';//ភ្ជាប់db

// Check 
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // ប្រសិនបើគ្មាន id (មិនតានបាន loin​)នោះនិង load ​ទៅ page login
    exit();
}

// Check មិនសំខាន់អាចលុបបាន
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header("Location: my_order_confirmation.php"); //ប្រសិនបើគ្មាន អីវ់ានដែលដាក់ចូល cartនោះនិង load ​ទៅ page  my_order_confirmation.php
    exit();
}


// Fetch user details
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM user WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Handle the form submission

// Handle the form submission
// Handle the form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $payment_method = $_POST['payment_method'];

    // Prepare to save order to the database
    $order_date = date('Y-m-d H:i:s');
    $total_price = 0;

    // Create a flag to track if stock is sufficient
    $stock_sufficient = true;
    $insufficient_stock_items = [];

    // Check stock availability
    foreach ($_SESSION['cart'] as $item) {
        // Fetch the current stock for the item
        $sql = "SELECT stock FROM model WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $item['id']);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        // Check if enough stock is available
        if ($row['stock'] < $item['quantity']) {
            $stock_sufficient = false;
            $insufficient_stock_items[] = htmlspecialchars($item['name']);
        }
    }

    if (!$stock_sufficient) {
        echo "Not enough stock available for: " . implode(", ", $insufficient_stock_items) . ". Please reduce the quantity.";
        exit(); // Stop further execution if stock is insufficient
    }

    // Proceed with inserting order and updating stock
    $sql = "INSERT INTO orders (user_id, order_date, total_price) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isd", $user_id, $order_date, $total_price);
    $stmt->execute();
    $order_id = $stmt->insert_id; // Get the last inserted order ID

    // Insert order items and update stock
    foreach ($_SESSION['cart'] as $item) {
        $item_total = $item['price'] * $item['quantity'];
        $total_price += $item_total;

        // Insert into order_items table
        $sql = "INSERT INTO order_items (order_id, model_id, quantity, price) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiid", $order_id, $item['id'], $item['quantity'], $item['price']);
        $stmt->execute();

        // Update stock in the database
        $sql = "UPDATE model SET stock = stock - ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $item['quantity'], $item['id']);
        $stmt->execute();
    }

    // Update the total price of the order
    $sql = "UPDATE orders SET total_price = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("di", $total_price, $order_id);
    $stmt->execute();

    // Clear the cart
    unset($_SESSION['cart']);

    // Redirect or handle payment methods
    if ($payment_method === 'paypal') {
        header("Location: paypal_payment.php?order_id=" . $order_id);
        exit();
    } else if ($payment_method === 'visa') {
        echo "Processing Visa payment...";
        exit();
    } else if ($payment_method === 'qr') {
        header("Location: my_order_confirmation.php");
        exit();
    } else {
        echo "Invalid payment method.";
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        #qr_code { display: none; }
        #countdown { display: none; }
        #success_message { display: none; }

        .QRprice {
    transform: translate(100px, 200px);
}
    </style>
</head>
<body>

    <!-- Navigation Bar -->
    <?php include 'includes/nav.php'; ?>


<div class="container mt-5">
    <h2>Checkout</h2>
    <p>Review your order and complete the purchase.</p>

    <div class="row">


        <div class="col-md-6">
            <h4>email</h4>
            <p><?php echo htmlspecialchars($user['email']); ?></p>

            <h4>Shipping Address</h4>
            <p><?php echo htmlspecialchars($user['address']); ?></p>
        </div>

        
        
        <div class="col-md-6">
            <h4>Order Summary</h4>
            <?php
            $total_price = 0;
            if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])):
            ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>img</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($_SESSION['cart'] as $item):
                            $item_total = $item['price'] * $item['quantity'];
                            $total_price += $item_total;
                        ?>
                            <tr>
                                <td>
                                <?php if (!empty($item['img'])): ?>
                                    <?php if (filter_var($item['img'], FILTER_VALIDATE_URL)): ?>
                                        <img src="<?php echo htmlspecialchars($item['img']); ?>" alt="<?php echo htmlspecialchars($item['img']); ?>" class="img-fluid" style="max-width: 100px;">
                                    <?php else: ?>
                                        <img src="../uploads/imagesmodel/<?php echo htmlspecialchars($item['img']); ?>" alt="<?php echo htmlspecialchars($item['img']); ?>" class="img-fluid" style="max-width: 100px;">
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span>No Image</span>
                                <?php endif; ?>
                                
                                </td>

                                <td><a href="details.php?model_id=<?php echo htmlspecialchars($item['id']); ?>" class="car-link">
                       
                                    <?php echo htmlspecialchars($item['name']); ?>
                                    </a>
                                    
                                </td>
                                <td>$<?php echo number_format($item['price'], 2); ?></td>
                                <td><?php echo htmlspecialchars($item['quantity']); ?></td>

                                <td>$<?php echo number_format($item_total, 2); ?></td>
                            </tr>
                        <?php endforeach; ?>

                        <tr><td></td>
                            <td colspan="3" class="text-right"><strong>Total</strong></td>
                            <td><strong>$<?php echo number_format($total_price, 2); ?></strong></td>
                        </tr>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No items in cart.</p>
            <?php endif; ?>
            
            <h4>Payment Options</h4>
            <form id="checkout_form" method="POST" action="">
                <div class="form-group">
                    <label for="payment_method">Choose a payment method:</label>
                    <select id="payment_method" name="payment_method" class="form-control">
                        <option value="paypal">PayPal</option>
                        <option value="visa">Visa</option>
                        <option value="qr">KH QR</option>
                        <!-- Add more payment options if needed -->
                    </select>
                </div>
                <div id="visa_form" style="display: none;">
                    <h4>Visa Card Details</h4>
                    <div class="form-group">
                        <label for="card_number">Card Number</label>
                        <input type="text" id="card_number" name="card_number" class="form-control" placeholder="Enter card number" required>
                    </div>
                    <div class="form-group">
                        <label for="card_expiry">Expiry Date (MM/YY)</label>
                        <input type="text" id="card_expiry" name="card_expiry" class="form-control" placeholder="MM/YY" required>
                    </div>
                    <div class="form-group">
                        <label for="card_cvc">CVC</label>
                        <input type="text" id="card_cvc" name="card_cvc" class="form-control" placeholder="CVC" required>
                    </div>
                </div>
                

                <button type="submit" class="btn btn-success">Confirm Purchase</button>


                
                <div id="qr_code" style="display: none;">
                    <h4>QR Code</h4>
                    <p id="countdown" class="text-danger mt-2"></p>
                    <strong>        <h1 class="QRprice"> <strong><?php echo number_format($total_price, 2); ?>$ </strong></h1> </strong>
                    <img src="QR.png" alt="QR Code" class="img-fluid">


                  
                </div>
                <div id="success_message" class="alert alert-success mt-2" role="alert">Payment Successful!</div>


               
            </form>
        </div>
    </div>
</div>



<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
    document.getElementById('payment_method').addEventListener('change', function() {
        var paymentMethod = this.value;
        if (paymentMethod === 'visa') {
            document.getElementById('visa_form').style.display = 'block';
            document.getElementById('qr_code').style.display = 'none';
            document.getElementById('countdown').style.display = 'none';
            document.getElementById('success_message').style.display = 'none';
        } else if (paymentMethod === 'qr') {
            document.getElementById('visa_form').style.display = 'none';
            document.getElementById('qr_code').style.display = 'block';
            document.getElementById('success_message').style.display = 'none';
            
            // Countdown timer
            let countdownTime = 10; // 10 seconds
            const countdownElement = document.getElementById('countdown');
            countdownElement.style.display = 'block';
            countdownElement.innerText = `Time remaining: ${countdownTime} seconds`;
            
            const countdownInterval = setInterval(function() {
                countdownTime--;
                countdownElement.innerText = `Time remaining: ${countdownTime} seconds`;
                
                if (countdownTime <= 0) {
                    clearInterval(countdownInterval);
                    countdownElement.innerText = '';
                    document.getElementById('success_message').style.display = 'block';
                }
            }, 1000);
        } else {
            document.getElementById('visa_form').style.display = 'none';
            document.getElementById('qr_code').style.display = 'none';
            document.getElementById('countdown').style.display = 'none';
            document.getElementById('success_message').style.display = 'none';
        }
    });

    document.querySelector('button[type="submit"]').addEventListener('click', function(event) {
        event.preventDefault();
        const paymentMethod = document.getElementById('payment_method').value;
        if (paymentMethod === 'qr') {
            document.getElementById('success_message').style.display = 'block';
            setTimeout(function() {
                document.getElementById('success_message').style.display = 'none';
            }, 5000); // Hide success message after 5 seconds
        }
        document.getElementById('checkout_form').submit();
    });
</script>
</body>
</html>
