<?php
session_start();
include 'config/database.php';

// Search term
$search_term = isset($_GET['search']) ? '%' . $_GET['search'] . '%' : '';

// SQL to count total results
$count_sql = "SELECT COUNT(*) AS total 
              FROM model m 
              JOIN car_makers cm ON m.id_car_makers = cm.id 
              WHERE m.name LIKE ? 
              OR m.full_name LIKE ? 
              OR cm.maker_name LIKE ? 
              OR m.year LIKE ? 
              OR m.price LIKE ? 
              OR m.description LIKE ? 
              OR m.car_types LIKE ? 
              OR m.color LIKE ? 
              OR m.fuel_type LIKE ?";

// Prepare and execute statement
$stmt = $conn->prepare($count_sql);
$params = array_fill(0, 9, $search_term); // All parameters are the same
$stmt->bind_param(str_repeat('s', 9), ...$params);
$stmt->execute();
$count_result = $stmt->get_result();
$count_row = $count_result->fetch_assoc();
$total_results = $count_row['total'];

// Set number of results per page
$results_per_page = 6;

// Calculate total pages
$total_pages = ceil($total_results / $results_per_page);

// Determine current page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max(1, min($page, $total_pages)); // Ensure page number is within range

// Calculate starting limit
$start_from = ($page - 1) * $results_per_page;

// SQL to fetch paginated results
$fetch_sql = "SELECT * 
              FROM model m 
              JOIN car_makers cm ON m.id_car_makers = cm.id 
              WHERE m.name LIKE ? 
              OR m.full_name LIKE ? 
              OR cm.maker_name LIKE ? 
              OR m.year LIKE ? 
              OR m.price LIKE ? 
              OR m.description LIKE ? 
              OR m.car_types LIKE ? 
              OR m.color LIKE ? 
              OR m.fuel_type LIKE ? 
              LIMIT ?, ?";

// Prepare and execute statement
$stmt = $conn->prepare($fetch_sql);
$params = array_merge(array_fill(0, 9, $search_term), [$start_from, $results_per_page]);
$stmt->bind_param(str_repeat('s', 9) . 'ii', ...$params);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Models</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        .car-box {
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 5px;
            text-align: start;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            justify-content: center;
        }
        .car-box:hover {
            transform: translateY(-10px);
            box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.1);
        }
        .car-box img {
            max-width: 100%;
            height: auto;
            border-radius: 5px;
        }
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }
        .pagination li {
            margin: 0 5px;
        }
        .car-link {
            text-decoration: none;
        }
        .car-link:hover {
            text-decoration: none;
        }
    </style>
</head>
<body>

<!-- Navigation Bar -->
<?php include 'includes/nav.php'; ?>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#"></a>
    <div class="collapse navbar-collapse" id="navbarNav">
        <form method="GET" action="tesing.php" class="form-inline">
            <div class="form-group mr-2">
                <input type="text" name="search" class="form-control" placeholder="Search" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
            </div>
            <button type="submit" class="btn btn-primary">Search <i class="fas fa-search"></i></button>
        </form>
    </div>
</nav>

<!-- Car Models List -->
<div class="container mt-4">
    <div class="row">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="col-md-4">
                <div class="car-box">
                    <a href="car_details.php?id=<?php echo $row['id']; ?>" class="car-link">
                        <img src="<?php echo htmlspecialchars($row['img']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>">
                        <h5><?php echo htmlspecialchars($row['name']); ?></h5>
                        <p>Price: $<?php echo number_format($row['price'], 2); ?></p>
                        <p>Year: <?php echo htmlspecialchars($row['year']); ?></p>
                        <p>Type: <?php echo htmlspecialchars($row['car_types']); ?></p>
                        <p>Color: <?php echo htmlspecialchars($row['color']); ?></p>
                        <p>Fuel: <?php echo htmlspecialchars($row['fuel_type']); ?></p>
                    </a>
                </div>
            </div>
        <?php endwhile; ?>
    </div>

    <!-- Pagination -->
    <ul class="pagination">
        <?php if ($page > 1): ?>
            <li class="page-item">
                <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>">Previous</a>
            </li>
        <?php endif; ?>

        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
            <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>"><?php echo $i; ?></a>
            </li>
        <?php endfor; ?>

        <?php if ($page < $total_pages): ?>
            <li class="page-item">
                <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>">Next</a>
            </li>
        <?php endif; ?>
    </ul>
</div>

<!-- Footer -->
<?php include 'includes/footer.php'; ?>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
