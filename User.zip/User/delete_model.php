<?php
include 'config/database.php';


$id = $_GET['id'];
if (!$id) {
    die("Invalid request.");
}

// Delete the model
$query = "DELETE FROM model WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    header("Location: view_models.php");
    exit;
} else {
    header("Location: view_models.php");
    echo "Error deleting record: " . $stmt->error;
}


$stmt->close();
$conn->close();
?>
