<?php
session_start(); // Start session to access admin login status
include 'config/database.php'; // Include database configuration

// Check if the user is logged in and is an admin


// Get the order_id from the query string
if (!isset($_GET['order_id']) || !is_numeric($_GET['order_id'])) {
    echo "Invalid Order ID.";
    exit();
}

$order_id = intval($_GET['order_id']);

// Fetch order details including user address and email
$order_query = "SELECT o.id, o.order_date, o.total_price, u.first_name, u.last_name, u.email, u.address
                FROM orders o
                JOIN user u ON o.user_id = u.id
                WHERE o.id = ?";
$stmt = $conn->prepare($order_query);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    echo "Order not found.";
    exit();
}

// Fetch order items
$order_items_query = "SELECT oi.*, m.name, m.img FROM order_items oi
                      JOIN model m ON oi.model_id = m.id
                      WHERE oi.order_id = ?";
$stmt = $conn->prepare($order_items_query);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order_items_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .order-item img {
            max-width: 100px;
            height: auto;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <?php include 'includes/nav.php'; ?>



<div class="container mt-5">
    <h2>Order Details</h2>
    <div class="order-summary">
        <h3>Order ID: <?php echo htmlspecialchars($order['id']); ?></h3>
        <p>Order Date: <?php echo htmlspecialchars($order['order_date']); ?></p>
        <p>Total Price: $<?php echo number_format($order['total_price'], 2); ?></p>
        <p>User: <?php echo htmlspecialchars($order['first_name'] . ' ' . $order['last_name']); ?></p>
        <p>Email: <?php echo htmlspecialchars($order['email']); ?></p>
        <p>Address: <?php echo htmlspecialchars($order['address']); ?></p>
    </div>

    <h4>Order Items</h4>
    <?php if ($order_items_result->num_rows > 0): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Model Name</th>
                    <th>Quantity</th>
                    <th>Price Each</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($item = $order_items_result->fetch_assoc()): ?>
                    <tr>
                        <td class="order-item">
                            <?php if ($item['img']): ?>
                                <img src="../uploads/imagesmodel/<?php echo htmlspecialchars($item['img']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                            <?php else: ?>
                                No Image
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($item['name']); ?></td>
                        <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                        <td>$<?php echo number_format($item['price'], 2); ?></td>
                        <td>$<?php echo number_format($item['quantity'] * $item['price'], 2); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No items found for this order.</p>
    <?php endif; ?>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
