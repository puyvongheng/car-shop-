<?php
session_start();
include 'config/database.php';



//----------------------------------------------------------------
if (!isset($_GET['model_id'])) {//ប្រសិនជាមិនអោយ modele_id ​ទៅវា
    die("Model ID not specified.");
}
//​ detail model car
$model_id = intval($_GET['model_id']);//ចាប់យកតម្លៃ model_id​ដែលគេបាន​ បោះអោយ
// Fetch car model details from the database
$sql = "SELECT m.*, cm.maker_name
        FROM model m
        JOIN car_makers cm ON m.id_car_makers = cm.id
        WHERE m.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $model_id);
$stmt->execute();
$result = $stmt->get_result();
$model = $result->fetch_assoc();
//ប្រសិនជាគ្មានទេ 
if (!$model) {
    die("Car model not found.");
}
//---------------------------------------------------------------

// Fetch(ទាញយក) available(មាន) car models for the bottom section
$models_sql = "SELECT id, name, price, img FROM model";
$models_result = $conn->query($models_sql);


// Handle adding to cart(បញ្ចូល​ ទៅ cart )
if (isset($_POST['add_to_cart']) && isset($_SESSION['user_id'])) {
    $cart_model_id = intval($_POST['model_id']);
    $quantity = intval($_POST['quantity']);
    // Initialize cart if not set
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = array();
    }
    // Add or update item in cart
    if (isset($_SESSION['cart'][$cart_model_id])) {
        $_SESSION['cart'][$cart_model_id]['quantity'] += $quantity;
    } else {
        $_SESSION['cart'][$cart_model_id] = array(
            'name' => $model['name'],
            'price' => $model['price'],
            'quantity' => $quantity,
            'image' => $model['img']
        );
    }
    // Redirect to cart
    header("Location: view_cart.php");
    exit();
}


// Fetch reviews for the specific car model
$reviews_sql = "SELECT r.*, u.first_name AS reviewer_name 
                FROM reviews r
                JOIN user u ON r.user_id = u.id
                WHERE r.model_id = ?";
$stmt_reviews = $conn->prepare($reviews_sql);
$stmt_reviews->bind_param('i', $model_id);
$stmt_reviews->execute();
$reviews_result = $stmt_reviews->get_result();
$reviews = $reviews_result->fetch_all(MYSQLI_ASSOC);




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Model Details</title>
    <link rel="icon" href="Timmerman.png" type="image/png">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        .car-box {
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 5px;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .car-box:hover {
            transform: translateY(-10px);
            box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.1);
        }
        .car-box img {
            max-width: 100%;
            height: auto;
            border-radius: 5px;
          
        }
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }
        .pagination li {
            margin: 0 5px;
        }

        .car-link {
        text-decoration: none;
      
    }
    .car-link:hover  {
        text-decoration: none;
      
    }
    img{
        border-radius: 10px;
    }




    .star-rating {
            font-size: 1.5rem;
            color: #ff9800;
        }
        .review-text {
            margin-top: 10px;
        }
        .review-card {
            margin-bottom: 20px;
            position: relative;
            border-left: 5px solid #007bff;
        }
        .review-card .user-icon {
            position: absolute;
            top: -20px;
            left: -40px;
            background-color: #007bff;
            border-radius: 50%;
            padding: 10px;
            color: #fff;
            font-size: 2rem;
        }
        .review-card .review-header {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }
        .review-card .review-header .user-icon {
            margin-right: 15px;
        }
        .addcart {
            position: fixed;
            display: flex;
            justify-content: end;
            border-radius: 20px 20px 0px 0px;

            bottom: 0;
            right: 0;
            width: 100%;

            background-color: #007bff;
            color: white;
            text-align: end;
            padding: 15px;
            z-index: 1000;
        }
        .add{
            border-radius: 50px;
        }
                .sticky-btn {
        
         /*   position: sticky;*/            top: 10px; /* Distance from the top of the viewport */
            right: 10px; /* Distance from the right side of the viewport */
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            z-index: 1000; /* Ensure it's above other content */
        
        }

        /*ttttttttttttttttttttttttttt */
        /* Custom class to handle dropdown hover */
.dropdown-hover:hover .dropdown-menu {
    display: block;
}

.dropdown-menu {
    display: none; /* Ensure dropdown menu is hidden by default */
    position: absolute;
    top: 100%;
    left: 0;
    z-index: 1000; /* Ensure dropdown menu appears on top */
}

.car-type-icon {
    width: 30px;
    height: 30px;
    margin-right: 8px;
    vertical-align: middle;
    transition: transform 0.3s ease; /* Smooth transition for hover effect */
}

.dropdown-item:hover .car-type-icon {
    transform: scale(1.2); /* Scale up the icon on hover */
}

.color-icon {
    display: inline-block;
    width: 16px;
    height: 16px;
    border-radius: 50%;
    margin-right: 8px;
    border: 1px solid #ccc; /* Optional: Add border to the color icon */
}

     
    
    </style>
</head>
<body>
<!-- Navigation Bar -->
<?php include 'includes/nav.php'; ?>

<!--nav seach🔍--><nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#"></a>
    <div class="collapse navbar-collapse" id="navbarNav">
        <form method="GET" action="index.php" class="form-inline">
            <?php
            // Fetch car makers and their logos from the database
            $carmaker_sql = "SELECT DISTINCT id, maker_name, logo FROM car_makers";
            $carmaker_result = $conn->query($carmaker_sql);
            ?>

            <div class="form-group mr-2">
                <input type="text" name="name" class="form-control" placeholder="Car Name" value="<?php echo isset($_GET['name']) ? htmlspecialchars($_GET['name']) : ''; ?>">
            </div>

            <div class="dropdown dropdown-hover mr-2">
                <button class="btn btn-secondary dropdown-toggle" type="button" id="carmakerDropdown" aria-haspopup="true" aria-expanded="false">
                    <?php echo isset($_GET['carmaker']) ? htmlspecialchars($carmaker_row['maker_name']) : 'Maker'; ?>
                </button>
                <div class="dropdown-menu" aria-labelledby="carmakerDropdown">
                    <a class="dropdown-item" href="#">Maker</a>
                    <?php while ($carmaker_row = $carmaker_result->fetch_assoc()): ?>

                        <a class="dropdown-item" href="index.php?carmaker=<?php echo $carmaker_row['id']; ?>">


                        <?php if (filter_var($carmaker_row['logo'], FILTER_VALIDATE_URL)): ?>
                            <img src="<?php echo htmlspecialchars($carmaker_row['logo']); ?>" alt="<?php echo htmlspecialchars($carmaker_row['maker_name']); ?>" style="width: 30px; height: 30px; margin-right: 8px;">
                        <?php else: ?>

                            <img src="../Admin/src/uploads/logocarmake/<?php echo htmlspecialchars($carmaker_row['logo']); ?>" alt="Logo" style="width: 30px; height: 30px; margin-right: 8px;">
                        <?php endif; ?>



                           
                           
                            <?php echo htmlspecialchars($carmaker_row['maker_name']); ?>
                        </a>

                    <?php endwhile; ?>
                </div>
            </div>

            <div class="dropdown dropdown-hover mr-2">
                <button class="btn btn-secondary dropdown-toggle" type="button" id="carTypeDropdown" aria-haspopup="true" aria-expanded="false">
                    <?php echo isset($_GET['car_types']) ? htmlspecialchars($_GET['car_types']) : 'Car Type'; ?>
                </button>
                <div class="dropdown-menu" aria-labelledby="carTypeDropdown">
                    <a class="dropdown-item" href="#">Car Type</a>
                    <?php
                    // Define car types and their corresponding icon URLs
                    $car_types_icons = [
                        'Sedan' => 'https://th.bing.com/th/id/OIP.29CkB0_UO-Xl2W5-9FnwIAHaHa?rs=1&pid=ImgDetMain',
                        'SUV' => 'https://cdn3.iconfinder.com/data/icons/transport-solid-collection-1/60/014-SUV-1024.png',
                        'Hatchback' => 'https://th.bing.com/th/id/OIP.PKmCtXuUIprcZucU5HadiwHaHa?rs=1&pid=ImgDetMain',
                        'Truck' => 'https://webstockreview.net/images/truck-png-images-14.png',
                        'Van' => 'https://th.bing.com/th/id/OIP.hsAfLGQeniV5faqWMyGBnQHaHa?rs=1&pid=ImgDetMain',
                        'Convertible' => 'https://cdn2.iconfinder.com/data/icons/vehicle-type/1024/convertible-1024.png',
                        'Coupe' => 'https://th.bing.com/th/id/OIP.OXMlz2dI88CxCVtKuTsXcQHaHa?rs=1&pid=ImgDetMain'
                        // Add more car types and their corresponding icons here
                    ];

                    $car_types_sql = "SELECT DISTINCT car_types FROM model ORDER BY car_types";
                    $car_types_result = $conn->query($car_types_sql);
                    while ($car_types_row = $car_types_result->fetch_assoc()):
                        $car_type = htmlspecialchars($car_types_row['car_types']);
                        $icon_url = isset($car_types_icons[$car_type]) ? $car_types_icons[$car_type] : 'https://example.com/default-icon.png';
                    ?>
                        <a class="dropdown-item" href="index.php?car_types=<?php echo urlencode($car_type); ?>">
                            <img src="<?php echo $icon_url; ?>" alt="<?php echo $car_type; ?>" class="car-type-icon">
                            <?php echo $car_type; ?>
                        </a>
                    <?php endwhile; ?>
                </div>
            </div>

            <div class="dropdown dropdown-hover mr-2">
                <button class="btn btn-secondary dropdown-toggle" type="button" id="colorDropdown" aria-haspopup="true" aria-expanded="false">
                    <?php echo isset($_GET['color']) ? htmlspecialchars($_GET['color']) : 'Color'; ?>
                </button>
                <div class="dropdown-menu" aria-labelledby="colorDropdown">
                    <a class="dropdown-item" href="#">Color</a>
                    <?php
                    // Fetch unique colors from the model table
                    $color_sql = "SELECT DISTINCT color FROM model WHERE color IS NOT NULL AND color != '' ORDER BY color";
                    $color_result = $conn->query($color_sql);

                    while ($color_row = $color_result->fetch_assoc()):
                        $color_name = htmlspecialchars($color_row['color']);
                    ?>
                        <a class="dropdown-item" href="index.php?color=<?php echo urlencode($color_name); ?>">
                            <span class="color-icon" style="background-color: <?php echo htmlspecialchars($color_name); ?>;"></span> <?php echo $color_name; ?>
                        </a>
                    <?php endwhile; ?>
                </div>
            </div>

            <div class="dropdown dropdown-hover mr-2">
                <button class="btn btn-secondary dropdown-toggle" type="button" id="fuelTypeDropdown" aria-haspopup="true" aria-expanded="false">
                    <?php echo isset($_GET['fuel_type']) ? htmlspecialchars($_GET['fuel_type']) : 'Fuel Type'; ?>
                </button>
                <div class="dropdown-menu" aria-labelledby="fuelTypeDropdown">
                    <a class="dropdown-item" href="#">Fuel Type</a>
                    <?php
                    $fuel_type_sql = "SELECT DISTINCT fuel_type FROM model ORDER BY fuel_type";
                    $fuel_type_result = $conn->query($fuel_type_sql);
                    while ($fuel_type_row = $fuel_type_result->fetch_assoc()):
                        $fuel_type = $fuel_type_row['fuel_type'];
                        $icon = ''; // Default to no icon

                        // Determine the icon based on the fuel type
                        if ($fuel_type === 'Electric') {
                            $icon = '<i class="fas fa-bolt"></i>'; // Electric icon
                        } elseif ($fuel_type === 'Hybrid') {
                            $icon = '<i class="fas fa-car-battery"></i>'; // Hybrid icon
                        } elseif ($fuel_type === 'Gasoline') {
                            $icon = '<i class="fas fa-gas-pump"></i>'; // Gasoline icon
                        } elseif ($fuel_type === 'Diesel') {
                            $icon = '<i class="fas fa-oil-can"></i>'; // Diesel icon
                        } elseif ($fuel_type === 'Petrol') {
                            $icon = '<i class="fas fa-gas-pump"></i>'; // Petrol icon (same as Gasoline)
                        }
                    ?>
                        <a class="dropdown-item" href="index.php?fuel_type=<?php echo urlencode($fuel_type); ?>">
                            <?php echo htmlspecialchars($fuel_type); ?> 
                            <?php echo $icon; ?> <!-- Icon after the text -->
                        </a>
                    <?php endwhile; ?>
                </div>
            </div>

            <div class="form-group mr-2">
                <input type="number" name="price" class="form-control" placeholder="Max Price$" value="<?php echo isset($_GET['price']) ? htmlspecialchars($_GET['price']) : ''; ?>">
            </div>

            <button type="submit" class="btn btn-primary">Search <i class="fas fa-search"></i></button>
        </form>
    </div>
</nav>
<!--end nav seach🔍-->

<!-- nav back-->
<!--btn back🔙-->
<button class="sticky-btn bg-light " style="color: black; width: 100%; text-align :start;"  onclick="window.history.back()">Back</button>
 <!--btn back🔙-->














<!--contenner model detill top🔝 -->
<div class="container mt-5">



<div class="container ">
    <div class="row">
        <!-- Car Image Section ​រូបភាព 📷-->
        <div class="col-md-10">
            <?php if ($model['img']): ?>
                <?php if (filter_var($model['img'], FILTER_VALIDATE_URL)): ?>
                    <img style="width: 100%;" src="<?php echo htmlspecialchars($model['img']); ?>" alt="Image" class="img-fluid">
                <?php else: ?>
                    <img src="../../Admin/src/uploads/imagesmodel/<?php echo htmlspecialchars($model['img']); ?>" alt="Image" class="img-fluid">
                <?php endif; ?>
            <?php else: ?>
                <p>No Image Available</p>
            <?php endif; ?>
        </div>
        <!--end Car Image Section រូបភាព 📷-->

        <!-- Car Details Section -->
       <div class="col-md-10"> 
       <div class="row">
    <div class="col-md-8">   
    <h1 >
        <strong style="color: red;">$<?php echo number_format($model['price'], 2); ?></strong>  
        </div>

            <div class="col-md-4">
                        <div class="row">
                    <!-- btn Love❤️-->
                    <style>
                            .heart-red {
                            color: red;
                        }
                    </style>
                    <h6 id="heartButton" class="col-md-3 btn" style=" border-radius:30px"><i id="heartIcon" class="fa-regular fa-heart"></i></h6>
                    <script>
                        document.getElementById('heartButton').addEventListener('click', function() {
                            var heartIcon = document.getElementById('heartIcon');
                            if (heartIcon.classList.contains('fa-regular')) {
                                heartIcon.classList.remove('fa-regular');
                                heartIcon.classList.add('fa-solid');
                                heartIcon.classList.add('heart-red');
                            } else {
                                heartIcon.classList.remove('fa-solid');
                                heartIcon.classList.add('fa-regular');
                                heartIcon.classList.remove('heart-red');
                            }
                        });

                    </script>
                    <!-- btn Love❤️-->
                    <!--btn sherae↩️-->
                    <h6 id="shareButton" class="btn col-md-4" style="background-color: white; color:black;  border-radius:30px"><i class="fa-solid fa-share-nodes"></i></h6>
                    <!--btn sherae↩️-->
                </div>
            </div>

        </div>
    </h1>
    <h2>Details   </h2>
    </div>
                <hr>







<div class="col-md-10">

<table class="table">
    <tbody>
        <tr>
            <th>Model Name</th>
            <td><?php echo htmlspecialchars($model['name']); ?></td>
        </tr>
        <tr>
            <th>Full Name</th>
            <td><?php echo htmlspecialchars($model['full_name']); ?></td>
        </tr>

        <tr>
            <th>Car Maker</th>

    <td>
        <?php
        // Fetch the car maker's details including the logo, full name, and country
        $maker_sql = "SELECT maker_name, full_name, logo, countries FROM car_makers WHERE id = ?";
        $stmt = $conn->prepare($maker_sql);
        $stmt->bind_param("i", $model['id_car_makers']);
        $stmt->execute();
        $maker_result = $stmt->get_result();
        $maker = $maker_result->fetch_assoc();
        
        if ($maker):
        ?>


<?php if (filter_var($maker['logo'], FILTER_VALIDATE_URL)): ?>
                            <img src="<?php echo htmlspecialchars($maker['logo']); ?>" alt="<?php echo htmlspecialchars($maker['maker_name']); ?>" style="width: 30px; height: 30px; margin-right: 8px;">
                        <?php else: ?>

                            <img src="../Admin/src/uploads/logocarmake/<?php echo htmlspecialchars($maker['logo']); ?>" alt="Logo" style="width: 30px; height: 30px; margin-right: 8px;">
                        <?php endif; ?>

        

                    
    
           
            <?php echo htmlspecialchars($maker['maker_name']); ?><br>
            <small><?php echo htmlspecialchars($maker['full_name']); ?></small><br>
            <small><?php echo htmlspecialchars($maker['countries']); ?></small>
       
       
            <?php else: ?>
            No information available
        <?php endif; ?>
    </td>
</tr>


        <tr>
            <th>Year</th>
            <td><?php echo htmlspecialchars($model['year']); ?></td>
        </tr>
        <tr>
            <th>Price</th>
            <td>$<?php echo number_format($model['price'], 2); ?></td>
        </tr>
        <tr>
            <th>Description</th>
            <td><?php echo htmlspecialchars($model['description']); ?></td>
        </tr>
        <tr>
            <th>Car Types</th>
            <td><?php echo htmlspecialchars($model['car_types']); ?></td>
        </tr>

        
        <tr>
    <th>Color</th>
    <td>
        <?php
        // Get the color from the model data
        $color = htmlspecialchars($model['color']);
        
        // Display the color name with a colored icon
        if ($color):
        ?>
            <span class="color-icon" style="background-color: <?php echo $color; ?>;"></span>
            <?php echo $color; ?>
        <?php else: ?>
            No color information available
        <?php endif; ?>
    </td>
</tr>
        <tr>
            <th>Fuel Type</th>
            <td><?php echo htmlspecialchars($model['fuel_type']); ?></td>
        </tr>
        <tr>
            <th>Stock</th>
            <td><?php echo htmlspecialchars($model['stock']); $model_stock = $model['stock'];?></td>
        </tr>
    </tbody>
</table>


<!-- end table ditall-->

<!-- footer add to cart ➕-->
<?php
$cart_quantity = 0;
if (isset($_SESSION['cart'][$model['id']])) {
    $cart_quantity = $_SESSION['cart'][$model['id']]['quantity'];
}
$remaining_stock = $model_stock - $cart_quantity;
?>

<div class="addcart">
    <?php if (isset($_SESSION['user_id'])): ?><!-- Check if the user is logged in -->

        <?php if ($remaining_stock > 0): ?><!-- Check if stock is greater than 0 -->
            <p style=" margin-right: 20px;">Stock remaining:: <?php echo $remaining_stock; ?></p>
            <a href="cart.php?model_id=<?php echo $model['id']; ?>" class="btn btn-primary Add">
                <i class="fas fa-shopping-cart"></i> Add to Cart
            </a>
        <?php else: ?><!-- If stock is 0, show out of stock message ប្រសិនជាគ្មានស្តុកទេ -->
            <p style=" margin-right: 20px;">Stock remaining: 0</p><!-- Display zero stock -->
            <a href="#" class="btn btn-secondary Add" style="cursor: not-allowed;">
                <i class="fas fa-shopping-cart"></i> Out of Stock
            </a>
        <?php endif; ?>
        
    <?php else: ?><!-- If the user is not logged in -->
        <p>
            <a href="login.php" class="btn btn-secondary Add">
                <i class="fas fa-shopping-cart"></i> Add to Cart
            </a>
        </p>
    <?php endif; ?>
</div>



 <!-- end footer add to cart ➕-->
        </div>
    </div>
</div>
<!--contenner model detill top🔝 -->




<!-- Modal Share ↩️-->
<div class="modal fade "  id="shareModal" tabindex="-1" aria-labelledby="shareModalLabel" aria-hidden="true">
    <div class="modal-dialog ">
        <div class="modal-content">
            <div class="modal-body">
                <p class="mt-4">Scan the QR code to open this page on your phone:</p>
                <div id="qrCode" class="img-fluid mx-auto d-block" style="max-width: 300px; height: auto;"></div>
                <p>Copy the link below to share this page:</p>
                <div class="input-group mb-3">
                    <input type="text" id="pageUrl" class="form-control" readonly>
                    <button type="button" class="btn btn-primary" onclick="copyLink()">Copy Link</button>
                    <button type="button" class="btn btn-success" id="saveQrCodeButton">Save</button>
                </div>
                <p class="mt-4">Or share directly:</p>
                <div class="d-flex justify-content-around flex-wrap">
                    <a href="#" id="facebookShare" class="btn btn-outline-primary mb-2"><i class="fab fa-facebook-f"></i> Facebook</a>
                    <a href="#" id="twitterShare" class="btn btn-outline-info mb-2"><i class="fab fa-twitter"></i> Twitter</a>
                    <a href="#" id="linkedinShare" class="btn btn-outline-primary mb-2"><i class="fab fa-linkedin-in"></i> LinkedIn</a>
                    <a href="#" id="telegramShare" class="btn btn-outline-primary mb-2"><i class="fab fa-telegram-plane"></i> Telegram</a>
                    <a href="#" id="messengerShare" class="btn btn-outline-primary mb-2"><i class="fab fa-facebook-messenger"></i> Messenger</a>
                    <a href="#" id="whatsappShare" class="btn btn-outline-success mb-2"><i class="fab fa-whatsapp"></i> WhatsApp</a>
                </div>
                    </div>
        </div>
    </div>
</div>
<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/qr-code-styling@1.5.0/lib/qr-code-styling.js"></script>
<script>
    var qrCode;

    document.getElementById('shareButton').addEventListener('click', function() {
        // Get the current page URL
        var currentUrl = window.location.href;
        
        // Set the URL in the modal input field
        document.getElementById('pageUrl').value = currentUrl;

        // Set the share URLs
        var encodedUrl = encodeURIComponent(currentUrl);
        document.getElementById('facebookShare').href = "https://www.facebook.com/sharer/sharer.php?u=" + encodedUrl;
        document.getElementById('twitterShare').href = "https://twitter.com/intent/tweet?url=" + encodedUrl;
        document.getElementById('linkedinShare').href = "https://www.linkedin.com/sharing/share-offsite/?url=" + encodedUrl;
        document.getElementById('telegramShare').href = "https://t.me/share/url?url=" + encodedUrl;
        document.getElementById('messengerShare').href = "fb-messenger://share/?link=" + encodedUrl;
        document.getElementById('whatsappShare').href = "https://api.whatsapp.com/send?text=" + encodedUrl;

        // Remove existing QR code if any
        var qrCodeContainer = document.getElementById('qrCode');
        qrCodeContainer.innerHTML = '';

        // Generate the QR code with logo using qr-code-styling
        qrCode = new QRCodeStyling({
            width: 300,
            height: 300,
            data: currentUrl,
            image: "Timmerman.png", // Replace with your logo URL
            dotsOptions: {
                color: "#000",
                type: "rounded"
            },
            backgroundOptions: {
                color: "#fff"
            },
            imageOptions: {
                crossOrigin: "anonymous",
                margin: 20,
                imageSize: 0.4
            }
        });
        
        qrCode.append(qrCodeContainer);

        // Save the QR code when the button is clicked
        document.getElementById('saveQrCodeButton').addEventListener('click', function() {
            qrCode.download({ name: "qr-code", extension: "png" });
        });

        // Show the modal
        var shareModal = new bootstrap.Modal(document.getElementById('shareModal'));
        shareModal.show();
    });

    function copyLink() {
        // Select the text in the input field
        var copyText = document.getElementById('pageUrl');
        copyText.select();
        copyText.setSelectionRange(0, 99999); // For mobile devices
        
        // Copy the text to the clipboard
        document.execCommand('copy');
        
        // Alert the user that the link has been copied
        alert('Link copied to clipboard!');
    }
</script>
<!--end  Modal Share ↩️-->

<hr>








<form action="submit_review.php" method="POST">


<?php if (isset($_SESSION['user_id'])): ?>
    <input type="hidden" name="user_id" value="<?php echo $_SESSION['user_id']; ?>"> <!-- or pass this dynamically -->
    <input type="hidden" name="model_id" value="<?php echo $model['id']; ?>"> <!-- Pass the current model's ID -->
    
    
<?php else: ?>
    <p>You need to be logged in to submit a review.</p>
<?php endif; ?>



 
    <div class="form-group">
        <label for="rating">Rate this:</label>
        <select class="form-control w-25" id="rating" name="rating">
            <option value="1">⭐</option>
            <option value="2">⭐⭐</option>
            <option value="3">⭐⭐⭐</option>
            <option value="4">⭐⭐⭐⭐</option>
            <option value="5">⭐⭐⭐⭐⭐</option>
        </select>
    </div>

    <div class="form-group">
        <label for="review">Write a review:</label>
        <textarea class="form-control" id="review" name="review" rows="4" placeholder="Share your thoughts..."></textarea>
    </div>


    <?php if (isset($_SESSION['user_id'])): ?>
    <button type="submit" class="btn btn-primary">Submit Review</button>
<?php else: ?>
    <p>You need to be logged in to submit a review.</p>
<?php endif; ?>




</form>


<?php // Calculate average rating
$total_rating = 0;
$num_reviews = count($reviews);
foreach ($reviews as $review) {
    $total_rating += $review['rating'];
}
$average_rating = ($num_reviews > 0) ? $total_rating / $num_reviews : 0; ?>





<div class="container mt-5">
    <h6>Ratings & Reviews</h6>

    <p>Total Average Rating: 
        <?php if ($average_rating > 0): ?>
            <?php for ($i = 0; $i < floor($average_rating); $i++): ?>
                <i class="fas fa-star"></i>
            <?php endfor; ?>
            <?php if ($average_rating - floor($average_rating) >= 0.5): ?>
                <i class="fas fa-star-half-alt"></i>
            <?php endif; ?>
            <?php for ($i = ceil($average_rating); $i < 5; $i++): ?>
                <i class="far fa-star"></i>
            <?php endfor; ?>
            <?php echo number_format($average_rating, 1); ?>/5
        <?php else: ?>
            No ratings available
        <?php endif; ?>
    </p>


    <?php if (!empty($reviews)): ?>
        <?php foreach ($reviews as $review): ?>
            <div class="review-card p-3 bg-light rounded">
                <div class="review-header">
                    <div class="star-rating">
                        <?php for ($i = 0; $i < $review['rating']; $i++): ?>
                            <i class="fas fa-star"></i>
                        <?php endfor; ?>
                        <?php for ($i = $review['rating']; $i < 5; $i++): ?>
                            <i class="far fa-star"></i>
                        <?php endfor; ?>
                    </div>
                    <span class="ml-2"><?php echo htmlspecialchars($review['rating']); ?>/5</span>

                </div>

                <p class="review-text"><?php echo htmlspecialchars($review['review_text']); ?></p>
                <small class="text-muted">Reviewed by <?php echo htmlspecialchars($review['reviewer_name']); ?>            on <?php echo date('F j, Y', strtotime($review['review_date'])); ?></small>
    

<!-- Check if the logged-in user has ordered this model -->






<?php if (isset($_SESSION['user_id']) && $review['user_id'] == $_SESSION['user_id']): ?>
    <div class="review-actions mt-2">
        <a href="edit_review.php?id=<?php echo $review['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
        <a href="delete_review.php?id=<?php echo $review['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this review?');">Delete</a>
    </div>
<?php else: ?>
  
    <!-- Code for non-owners or unauthenticated users can go here -->

<?php endif; ?>


            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No reviews found for this model.</p>
    <?php endif; ?>
</div>















<!-- end review 💞⭐⭐⭐   ------------------------------------------------------------------------------------------- -->


<hr>
<!-- top steel container box product 🚙🚙 🔝-->
<div class="container mt-4">
<div class="row">
    <div class="col-6">
        <h4>Top-Selling Car Models</h4>
    </div>
    <div class="col-6 text-end " style=" text-align: end;">
        <p><a href="Top-Selling.php" style="color: #007bff; text-align: end;">more ></a></p>
    </div>
</div>


<?php
// SQL query to get total sales for each model
$sql = "SELECT m.id, m.name, m.full_name, m.img, m.price, SUM(oi.quantity) AS total_quantity
        FROM model m
        JOIN order_items oi ON m.id = oi.model_id
        JOIN orders o ON oi.order_id = o.id
        GROUP BY m.id
        ORDER BY total_quantity DESC
        LIMIT 6";

$result = $conn->query($sql);

// Create an array to store total quantities
$quantities = [];
while ($row = $result->fetch_assoc()) {
    $quantities[] = $row['total_quantity'];
}
// Remove duplicate quantities and sort them in descending order
$quantities = array_unique($quantities);
rsort($quantities);

// Define rank thresholds based on sorted quantities
$rank_thresholds = [];
foreach ($quantities as $index => $quantity) {
    if ($index == 0) {
        $rank_thresholds['Top 1'] = $quantity;
    } elseif ($index == 1) {
        $rank_thresholds['Top 2'] = $quantity;
    } elseif ($index == 2) {
        $rank_thresholds['Top 3'] = $quantity;
    } else {
        break;
    }
}
// Re-run the query to fetch results for displaying
$result->data_seek(0);
?>
<div class="row">
    <?php if ($result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
            <?php
            // Determine the ranking based on the total quantity
            $ranking = "";
            if ($row['total_quantity'] >= $rank_thresholds['Top 1']) {
                $ranking = "Top 1";
            } elseif ($row['total_quantity'] >= $rank_thresholds['Top 2']) {
                $ranking = "Top 2";
            } elseif ($row['total_quantity'] >= $rank_thresholds['Top 3']) {
                $ranking = "Top 3";
            }
            ?>
            <div class="col-md-4 mb-4">
                <a href="details.php?model_id=<?php echo $row['id']; ?>" class="car-link">





                    <div class="car-box p-3 border rounded" style="text-align: start;">
                        <!--img -->
                        <?php if ($row['img']): ?>
                            <img src="<?php echo htmlspecialchars($row['img']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>" class="img-fluid mb-3">
                        <?php else: ?>
                            <p>No Image Available</p>
                        <?php endif; ?>
                        <!--end img-->

                        <h6><?php echo htmlspecialchars($row['name']); ?></h6>
                        <h4 style="color: red;"><strong>$<?php echo number_format($row['price'], 2); ?></strong></h4>
                        <p><?php echo $row['total_quantity']; ?> Sold ( <?php echo $ranking; ?>)
                        <img height="10px" width="70px" src="https://static.vecteezy.com/system/resources/thumbnails/021/630/211/small_2x/stars-customer-reviews-illustration-png.png" alt="">

                    </p>
                     
                    </div>
                </a>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No car models available.</p>
    <?php endif; ?>

    <?php $conn->close(); ?>
</div>
</div>
<!-- container box product 🚙🚙 🔝-->


<hr>
<!--
-------------------------------------------------------------------------------------------
    -->













<!--ស្រដៀងគ្នា-->
ុ<?php
include 'config/database.php';
$model_id = $_GET['model_id'];
// ទាញយកព័ត៌មានពីម៉ូដែលជាក់លាក់
$sql = "SELECT * FROM model WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $model_id);
$stmt->execute();
$model = $stmt->get_result()->fetch_assoc();
// បញ្ចូលព័ត៌មានអំពីប្រភេទឡានដែលស្រដៀងគ្នា
$sql_similar = "SELECT id, name, img, price FROM model WHERE car_types = ? AND id != ? LIMIT 5";
$stmt_similar = $conn->prepare($sql_similar);
$stmt_similar->bind_param("si", $model['car_types'], $model_id);
$stmt_similar->execute();
$similar_models = $stmt_similar->get_result();
?>







<div class="container mt-5">

    <div class="row">


        <div class="col-md-8">
            <!-- Display current model details here -->
            <img src="<?php echo htmlspecialchars($model['img']); ?>" alt="<?php echo htmlspecialchars($model['name']); ?>" class="img-fluid">
            <h2><?php echo htmlspecialchars($model['name']); ?></h2>
            <h4 style="color: red;"><strong>$<?php echo number_format($model['price'], 2); ?></strong></h4>
            <p><?php echo htmlspecialchars($model['description']); ?></p>
        </div>
        

        <div class="col-md-4">
        <div  style=" text-align: end;">
        <p><a href="Similar Models.php?model_id=<?php echo $model['id']; ?>" style="color: #007bff; text-align: end;">more ></a></p>
    </div>



            <h3>Similar Models</h3>

            





            <?php if ($similar_models->num_rows > 0): ?>
                <?php while ($row = $similar_models->fetch_assoc()): ?>

                    <a href="details.php?model_id=<?php echo $row['id']; ?>" >
                    <div class="similar-car-box mb-4 p-3 border rounded" style="text-align: start;">
                        <!-- img -->
                         
                        <?php if ($row['img']): ?>
                            <img src="<?php echo htmlspecialchars($row['img']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>" class="img-fluid mb-3">
                        <?php else: ?>
                            <p>No Image Available</p>
                        <?php endif; ?>
                        <!-- end img -->

                        <h6><?php echo htmlspecialchars($row['name']); ?></h6>
                        <h4 style="color: red;"><strong>$<?php echo number_format($row['price'], 2); ?></strong></h4>
                
                    </div>
                    </a>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No similar models found.</p>
            <?php endif; ?>

        </div>

    </div>
</div>
<?php $conn->close(); ?>
<!--ស្រដៀងគ្នា-->















<!--
-------------------------------------------------------------------------------------------
-->
<hr>

<!-- contener box product​ 🚙🚙-->
<div class="container mt-5"></div>
    <div class="row">
    <?php if ($models_result->num_rows > 0): ?><!--​ប្រសិនជាមាន model ឡាន-->
        <?php while ($row = $models_result->fetch_assoc()): ?>
            <div class="col-md-4">
                <a href="details.php?model_id=<?php echo $row['id']; ?>" class="car-link"> <!-- link to detill-->
                    <div class="car-box" style="text-align: start;">
                        <!--រូបភាពឡាន-->
                        <?php if ($row['img']): ?>
                            <?php if (filter_var($row['img'], FILTER_VALIDATE_URL)): ?>
                                <img src="<?php echo htmlspecialchars($row['img']); ?>" alt="Image">
                            <?php else: ?>
                                <img src="../uploads/imagesmodel/<?php echo htmlspecialchars($row['img']); ?>" alt="Image">
                            <?php endif; ?>
                        <?php else: ?>
                            <p>No Image Available</p>
                        <?php endif; ?>
                        <!--end រូបភាពឡាន-->


                        <p class=" text-dark"><?php echo htmlspecialchars($row['name']); ?></p>
                            <h4 style="color: red;" class=" custom-color"><strong>  $<?php echo number_format($row['price'], 2); ?> </strong></h4>
                      <P>            <img height="10px" width="70px" src="https://static.vecteezy.com/system/resources/thumbnails/021/630/211/small_2x/stars-customer-reviews-illustration-png.png" alt="">
                      </P>

                    </div>
                </a><!-- end link -->
            </div>
        <?php endwhile; ?>
    <?php else: ?><!--ផ្តូយទៅវិញប្រសិនជាគ្មានទេនោះ-->
        <p>No car models available.</p>
    <?php endif; ?><!--ខន end-->
</div>
<!-- end contener box product​​ 🚙🚙-->


</div>

<!-- Navigation Bar -->
<?php include 'includes/footer.php'; ?>


<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>


<?php
$conn->close();
?>
