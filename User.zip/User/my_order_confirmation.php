<?php
session_start(); // Start session to access user login status
include 'config/database.php'; // Include database configuration

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}

// Fetch all orders for the logged-in user
$user_id = $_SESSION['user_id'];
$orders_query = "SELECT * FROM orders WHERE user_id = ?";
$stmt = $conn->prepare($orders_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$orders_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="status.css">
 
</head>
<body>
    <!-- Navigation Bar -->
    <?php include 'includes/nav.php'; ?>
    
    <div class="container mt-5">

    <?php 
    // Modify the query to sort orders by ID in descending order
    $orders_query = "SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC";
    $stmt = $conn->prepare($orders_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $orders_result = $stmt->get_result();

    if ($orders_result->num_rows > 0): ?>
        <?php while ($order = $orders_result->fetch_assoc()): ?>
            <div class="order-summary">
                <h5>Order ID: <?php echo htmlspecialchars($order['id']); ?></h5>
                <p>Order Date: <?php echo htmlspecialchars($order['order_date']); ?></p>
                <p>Total Price: $<?php echo number_format($order['total_price'], 2); ?></p>
            </div>

            <?php
            // Fetch order items for the current order
            $order_id = $order['id'];
            $order_items_query = "SELECT oi.*, m.name, m.img FROM order_items oi
                                  JOIN model m ON oi.model_id = m.id
                                  WHERE oi.order_id = ?";
            $stmt = $conn->prepare($order_items_query);
            $stmt->bind_param("i", $order_id);
            $stmt->execute();
            $order_items_result = $stmt->get_result();
            ?>

            <div class="order-details">
                <h6>Order Items</h6>
                <div class="order-items">
                    <div class="order-item-header">
                        <div class="header-cell">Image</div>
                        <div class="header-cell">Model Name</div>
                        <div class="header-cell">Quantity</div>
                        <div class="header-cell">Price Each</div>
                        <div class="header-cell">Total</div>
                        <div class="header-cell">Status</div>
                    </div>
                    <?php while ($item = $order_items_result->fetch_assoc()): ?>
                        <div class="order-item-row">
                                 <!--img-->
                            <div class="order-item-cell">
                                <a href="details.php?model_id=<?php echo htmlspecialchars($item['model_id']); ?>" class="car-link">

                                  <?php
                                $image_url = "../../Admin/src/uploads/imagesmodel/" . htmlspecialchars($item['img']);
                                if (file_exists($image_url) && !empty($item['img'])):
                                ?>
                                    <img src="<?php echo $image_url; ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                                <?php else: ?>
                                    <img src="<?php echo htmlspecialchars($item['img']); ?>" alt="Image" style="width: 100px;">
                                <?php endif; ?>

                                </a>
                            </div>
                                <!--Model Name-->
                            <div class="order-item-cell">
                                <a href="details.php?model_id=<?php echo htmlspecialchars($item['model_id']); ?>" class="car-link">
                                    <?php echo htmlspecialchars($item['name']); ?>
                                </a>
                            </div>
                                <!--Quantity-->
                            <div class="order-item-cell"><?php echo htmlspecialchars($item['quantity']); ?></div>
                                <!--Price Each-->
                            <div class="order-item-cell">$<?php echo number_format($item['price'], 2); ?></div>
                                <!--Total-->
                            <div class="order-item-cell">$<?php echo number_format($item['quantity'] * $item['price'], 2); ?></div>
                            <!--status-->
                            <div class="order-item-cell">
                                <div class="statuss <?php echo 'status-' . strtolower(str_replace(' ', '-', $item['status'])); ?>">
                                <div><?php echo htmlspecialchars($item['status'] ?? 'N/A'); ?></div>
                                </div>
                            </div>
                            <!--status-->
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>

        <?php endwhile; ?>
    <?php else: ?>
        <p>You have no orders yet.</p>
    <?php endif; ?>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
