<?php
// Include database configuration
include 'config/database.php'; // Adjust the path as needed

// Fetch car makers for select input
$makersQuery = "SELECT id, maker_name FROM car_makers";
$makersResult = $conn->query($makersQuery);

// Check if connection was successful
if (!$conn) {
    die("Database connection failed.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST['name'];
    $full_name = $_POST['full_name'];
    $car_maker_id = $_POST['car_maker_id'];
    $year = $_POST['year'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $car_types = $_POST['car_types'];
    $color = $_POST['color'];
    $fuel_type = $_POST['fuel_type'];
    
    // Handle file upload
    $img = '';
    if (isset($_FILES['img']) && $_FILES['img']['error'] == 0) {
        $targetDir = "uploads/imagesmodel/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0755, true); // Create directory if it does not exist
        }
        $targetFile = $targetDir . basename($_FILES["img"]["name"]);
        if (move_uploaded_file($_FILES["img"]["tmp_name"], $targetFile)) {
            $img = basename($_FILES["img"]["name"]);
        } else {
            echo "Error uploading file.";
        }
    }

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO model (name, full_name, id_car_makers, year, price, description, car_types, color, fuel_type, img) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssiissssss", $name, $full_name, $car_maker_id, $year, $price, $description, $car_types, $color, $fuel_type, $img);

    // Execute the statement
    if ($stmt->execute()) {
        // Redirect to the same page to clear POST data (optional)
        header("Location: add_model.php");
        exit;
    } else {
        echo "Error inserting data: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Model</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Add Model</h2>
    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <div class="form-group">
            <label for="full_name">Full Name:</label>
            <input type="text" class="form-control" id="full_name" name="full_name">
        </div>
        <div class="form-group">
            <label for="car_maker_id">Car Maker:</label>
            <select class="form-control" id="car_maker_id" name="car_maker_id" required>
                <?php while ($row = $makersResult->fetch_assoc()): ?>
                    <option value="<?php echo htmlspecialchars($row['id']); ?>">
                        <?php echo htmlspecialchars($row['maker_name']); ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="year">Year:</label>
            <input type="number" class="form-control" id="year" name="year" required>
        </div>
        <div class="form-group">
            <label for="price">Price:</label>
            <input type="number" class="form-control" id="price" name="price" required>
        </div>
        <div class="form-group">
            <label for="description">Description:</label>
            <textarea class="form-control" id="description" name="description" rows="3"></textarea>
        </div>
        <div class="form-group">
            <label for="car_types">Car Types:</label>
            <input type="text" class="form-control" id="car_types" name="car_types">
        </div>
        <div class="form-group">
            <label for="color">Color:</label>
            <select class="form-control" id="color" name="color">
                <option value="Beige">Beige</option>
                <option value="Black">Black</option>
                <option value="Blue">Blue</option>
                <option value="Brown">Brown</option>
                <option value="Gold">Gold</option>
                <option value="Gray">Gray</option>
                <option value="Green">Green</option>
                <option value="Orange">Orange</option>
                <option value="Purple">Purple</option>
                <option value="Red">Red</option>
                <option value="Silver">Silver</option>
                <option value="White">White</option>
                <option value="Yellow">Yellow</option>
                <option value="Other">Other</option>
            </select>
        </div>
        <div class="form-group">
            <label for="fuel_type">Fuel Type:</label>
            <select class="form-control" id="fuel_type" name="fuel_type">
                <option value="Petrol">Petrol</option>
                <option value="Diesel">Diesel</option>
                <option value="Electric">Electric</option>
                <option value="Hybrid">Hybrid</option>
                <option value="Other">Other</option>
            </select>
        </div>
        <div class="form-group">
            <label for="img">Image:</label>
            <input type="file" class="form-control-file" id="img" name="img">
        </div>
        <button type="submit" class="btn btn-primary">Add Model</button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
// Close the connection
$conn->close();
?>
