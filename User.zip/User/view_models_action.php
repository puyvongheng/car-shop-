<?php
// Include database configuration
include 'config/database.php'; // Adjust the path as needed

// Check if connection was successful
if (!$conn) {
    die("Database connection failed.");
}

// Query to select data from the model table
$query = "SELECT m.id, m.name, m.full_name, cm.maker_name, m.year, m.price, m.description, m.car_types, m.color, m.fuel_type, m.img
          FROM model m
          JOIN car_makers cm ON m.id_car_makers = cm.id";
$result = $conn->query($query);

// Check if the query was successful
if (!$result) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Models</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>View Models</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Full Name</th>
                <th>Car Maker</th>
                <th>Year</th>
                <th>Price</th>
                <th>Description</th>
                <th>Car Types</th>
                <th>Color</th>
                <th>Fuel Type</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['maker_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['year']); ?></td>
                    <td><?php echo htmlspecialchars($row['price']); ?></td>
                    <td><?php echo htmlspecialchars($row['description']); ?></td>
                    <td><?php echo htmlspecialchars($row['car_types']); ?></td>
                    <td><?php echo htmlspecialchars($row['color']); ?></td>
                    <td><?php echo htmlspecialchars($row['fuel_type']); ?></td>
                    <td>

                    <?php if ($row['img']): ?>
                            <?php if (filter_var($row['img'], FILTER_VALIDATE_URL)): ?>
                                <img src="<?php echo htmlspecialchars($row['img']); ?>" alt="Image" style="width: 100px;">
                            <?php else: ?>
                                <img src="../uploads/imagesmodel/<?php echo htmlspecialchars($row['img']); ?>" alt="Image" style="width: 100px;">
                            <?php endif; ?>
                        <?php else: ?>
                            No Image
                        <?php endif; ?>
                        

                    </td>
                    <td>
                        <a href="edit_model.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="delete_model.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this model?');">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
// Close the connection
$conn->close();
?>
