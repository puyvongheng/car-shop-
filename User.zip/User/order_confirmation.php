<?php
session_start(); // Start session to access user login status
include 'config/database.php'; // Include database configuration

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}

// Fetch the order ID from the query parameter
$order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;

if ($order_id <= 0) {
    die("Invalid order ID.");
}

// Fetch order details from the database
$order_query = "SELECT * FROM orders WHERE id = ?";
$stmt = $conn->prepare($order_query);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order_result = $stmt->get_result();


if ($order_result->num_rows == 0) {
    die("Order not found.");
}


$order = $order_result->fetch_assoc();

// Fetch order items from the database
$order_items_query = "SELECT oi.*, m.name, m.img FROM order_items oi
                      JOIN model m ON oi.model_id = m.id
                      WHERE oi.order_id = ?";
$stmt = $conn->prepare($order_items_query);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order_items_result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .order-item img {
            max-width: 100px;
            height: auto;
        }
        .order-summary {
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <?php include 'includes/nav.php'; ?>
    

<div class="container mt-5">
    <h2>Order Confirmation</h2>
    <div class="order-summary">
        <p>Thank you for your purchase,
                    <!--     <?php echo htmlspecialchars($_SESSION['user_email']); ?>!-->
            
            </p>
        <p>Order ID: <?php echo htmlspecialchars($order['id']); ?></p>
        <p>Order Date: <?php echo htmlspecialchars($order['order_date']); ?></p>
        <p>Total Price: $<?php echo number_format($order['total_price'], 2); ?></p>
    </div>

    <h3>Order Items</h3>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Image</th>
                <th>Model Name</th>
                <th>Quantity</th>
                <th>Price Each</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($item = $order_items_result->fetch_assoc()): ?>
                <tr>
                    <td class="order-item">
                        <?php if ($item['img']): ?>
                            <img src="../uploads/imagesmodel/<?php echo htmlspecialchars($item['img']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                        <?php else: ?>
                            No Image
                        <?php endif; ?>
                    </td>
                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                    <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                    <td>$<?php echo number_format($item['price'], 2); ?></td>
                    <td>$<?php echo number_format($item['quantity'] * $item['price'], 2); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
