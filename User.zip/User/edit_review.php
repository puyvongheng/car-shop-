<?php
// Start session
session_start();

// Include database connection
include('config/database.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit;
}

// Check if the review ID is provided in the URL
if (isset($_GET['id'])) {
    $review_id = intval($_GET['id']); // Sanitize the input

    // Fetch the review details to ensure the logged-in user is the owner
    $query = "SELECT * FROM reviews WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $review_id, $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $review = $result->fetch_assoc();

    // Check if the review exists and belongs to the user
    if (!$review) {
        $_SESSION['error'] = "Review not found or you are not authorized to edit this review.";
        header("Location: details.php");
        exit;
    }
} else {
    $_SESSION['error'] = "No review ID provided.";
    header("Location: details.php");
    exit;
}

// Handle form submission for editing the review
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize and validate form input
    $rating = intval($_POST['rating']);
    $review_text = trim($_POST['review_text']);

    // Simple validation
    if ($rating >= 1 && $rating <= 5 && !empty($review_text)) {
        // Update the review in the database
        $update_query = "UPDATE reviews SET rating = ?, review_text = ? WHERE id = ? AND user_id = ?";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->bind_param("isii", $rating, $review_text, $review_id, $_SESSION['user_id']);

        if ($update_stmt->execute()) {
            // Success: Redirect with a success message
            $_SESSION['message'] = "Review updated successfully.";
            header("Location: details.php");
            exit;
        } else {
            $_SESSION['error'] = "Failed to update the review.";
        }
    } else {
        $_SESSION['error'] = "Please provide a valid rating and review text.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Review</title>
    <link rel="stylesheet" href="path/to/bootstrap.css"> <!-- Update with correct path -->
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Your Review</h2>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error']; ?></div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <form action="edit_review.php?id=<?php echo $review_id; ?>" method="POST">
            <div class="form-group">
                <label for="rating">Rating (1-5)</label>
                <select class="form-control" id="rating" name="rating" required>
                    <option value="1" <?php if ($review['rating'] == 1) echo 'selected'; ?>>1</option>
                    <option value="2" <?php if ($review['rating'] == 2) echo 'selected'; ?>>2</option>
                    <option value="3" <?php if ($review['rating'] == 3) echo 'selected'; ?>>3</option>
                    <option value="4" <?php if ($review['rating'] == 4) echo 'selected'; ?>>4</option>
                    <option value="5" <?php if ($review['rating'] == 5) echo 'selected'; ?>>5</option>
                </select>
            </div>

            <div class="form-group">
                <label for="review_text">Review</label>
                <textarea class="form-control" id="review_text" name="review_text" rows="4" required><?php echo htmlspecialchars($review['review_text']); ?></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Update Review</button>
            <a href="details.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>

    <script src="path/to/bootstrap.js"></script> <!-- Update with correct path -->
</body>
</html>
